function varargout = Software_xray(varargin)
% SOFTWARE_XRAY MATLAB code for Software_xray.fig
%      SOFTWARE_XRAY, by itself, creates a new SOFTWARE_XRAY or raises the existing
%      singleton*.
%
%      H = SOFTWARE_XRAY returns the handle to a new SOFTWARE_XRAY or the handle to
%      the existing singleton*.
%
%      SOFTWARE_XRAY('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SOFTWARE_XRAY.M with the given input arguments.
%
%      SOFTWARE_XRAY('Property','Value',...) creates a new SOFTWARE_XRAY or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Software_xray_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Software_xray_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Software_xray

% Last Modified by GUIDE v2.5 02-Mar-2022 11:27:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Software_xray_OpeningFcn, ...
                   'gui_OutputFcn',  @Software_xray_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Software_xray is made visible.
function Software_xray_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Software_xray (see VARARGIN)
addpath('functions')
handles.Iref = double(dicomread(['Ref_im\001']));
handles.Iref = handles.Iref./max(handles.Iref(:));
handles.savepath = 'Saved_data\';
% Choose default command line output for Software_xray
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Software_xray wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Software_xray_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Button_load_image.
function Button_load_image_Callback(hObject, eventdata, handles)
% hObject    handle to Button_load_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'right_FTANGLE')
    rmf = {'right_FTANGLE', 'left_FTANGLE', 'right_shaftcoords', 'left_shaftcoords', 'left_DIMS', 'right_DIMS', 'Manualedit', 'rightI', 'leftI', 'rightIc', 'leftIc', 'right_JS_loc', 'left_JS_loc', 'right_JSdimensions', 'left_JSdimensions', 'right_tibia_angle', 'left_tibia_angle'};
    handles = rmfield(handles, rmf);
end
if isfield(handles, 'loadfolder')
    [filename,folder] = uigetfile({'*.*', 'All Files (*.*)'}, 'Select a Dicom image folder',handles.loadfolder);    
else
    [filename,folder] = uigetfile({'*.*', 'All Files (*.*)'}, 'Select a Dicom image folder');
end
handles.loadfolder = folder;

handles = load_data(handles);

load_patient_data(handles)
handles = automatic_analysis(handles);

guidata(hObject, handles);

update_contrast(handles);
update_axes(handles);

function handles = load_data(handles)
try
handles.dcminfo = dicominfo([handles.loadfolder '001']);
handles.Iorig = double(dicomread([handles.loadfolder '001']));
catch
    handles.loadfolder = ['D' handles.loadfolder(2:end)];
    handles.dcminfo = dicominfo([handles.loadfolder '001']);
    handles.Iorig = double(dicomread([handles.loadfolder '001']));
end
% figure(1)
% subplot(1,3,1)
% imagesc(handles.Iorig)
% axis image
% colormap(gray)

handles.Iorighc = remove_bright_borders(handles.Iorig);

% subplot(1,3,2)
% imagesc(handles.Iorighc)
% axis image
% colormap(gray)

maxio = max(handles.Iorighc(:));
handles.Iorighc = handles.Iorighc./maxio;
handles.Iorighc = imhistmatch(handles.Iorighc, handles.Iref);
handles.Iorighc = handles.Iorighc.*maxio;

% subplot(1,3,3)
% imagesc(handles.Iorighc)
% axis image
% colormap(gray)


pixelsize = handles.dcminfo.PixelSpacing;
handles.pixelsize = pixelsize;
handles.JSmargin = round(25/pixelsize(1));
handles.TibiaROI = [round(10/pixelsize(1)) round(100/pixelsize(1))];
handles.MinWidth = round(10/pixelsize(1));
handles.JSlocTH = round(1/pixelsize(1));
handles.sidesmooth = round(200*pixelsize(1));
handles.ftanglesmooth = round(600*pixelsize(1));
handles.JSdimsmooth = round(300*pixelsize(1));
handles.addside = round(30/pixelsize(1));

handles.Imax = max(handles.Iorighc(:));
handles.Iorighe = histeq(handles.Iorighc./handles.Imax)*handles.Imax;
handles.Iorighef = medfilt2(handles.Iorighe,[handles.JSlocTH handles.JSlocTH]);

handles.Manualedit.JSset_left = 0;
handles.Manualedit.JSset_right = 0;
handles.Manualedit.FTfemur_left = 0;
handles.Manualedit.FTfemur_right = 0;
handles.Manualedit.FTtibia_left = 0;
handles.Manualedit.FTtibia_right = 0;
handles.Manualedit.JS_left = 0;
handles.Manualedit.JS_right = 0;
handles.Manualedit.CW_left = 0;
handles.Manualedit.CW_right = 0;
handles.Manualedit.Tweak_left = 0;
handles.Manualedit.Tweak_right = 0;
handles.Manualedit.Any_left = 0;
handles.Manualedit.Any_right = 0;
handles.Manualedit.Shaftangle_left = 0;
handles.Manualedit.Shaftangle_right = 0;
% figure(3)
% subplot(1,3,1)
% imagesc(handles.Iorig)
% colormap(gray)
% axis image
% subplot(1,3,2)
% imagesc(handles.Iorighc)
% colormap(gray)
% axis image
% subplot(1,3,3)
% imagesc(handles.Iorighef)
% colormap(gray)
% axis image

% --- Executes on slider movement.
function Slider_contrast_min_Callback(hObject, eventdata, handles)
% hObject    handle to Slider_contrast_min (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function Slider_contrast_min_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Slider_contrast_min (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function Slider_contrast_max_Callback(hObject, eventdata, handles)
% hObject    handle to Slider_contrast_max (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function Slider_contrast_max_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Slider_contrast_max (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in Show_histeq.
function Show_histeq_Callback(hObject, eventdata, handles)
% hObject    handle to Show_histeq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Show_histeq
update_axes(handles);


function Meas_FTangle_left_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_FTangle_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_FTangle_left as text
%        str2double(get(hObject,'String')) returns contents of Meas_FTangle_left as a double


% --- Executes during object creation, after setting all properties.
function Meas_FTangle_left_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_FTangle_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_MedJS_left_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_MedJS_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_MedJS_left as text
%        str2double(get(hObject,'String')) returns contents of Meas_MedJS_left as a double


% --- Executes during object creation, after setting all properties.
function Meas_MedJS_left_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_MedJS_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_LatJS_left_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_LatJS_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_LatJS_left as text
%        str2double(get(hObject,'String')) returns contents of Meas_LatJS_left as a double


% --- Executes during object creation, after setting all properties.
function Meas_LatJS_left_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_LatJS_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_MedCW_left_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_MedCW_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_MedCW_left as text
%        str2double(get(hObject,'String')) returns contents of Meas_MedCW_left as a double


% --- Executes during object creation, after setting all properties.
function Meas_MedCW_left_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_MedCW_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_LatCW_left_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_LatCW_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_LatCW_left as text
%        str2double(get(hObject,'String')) returns contents of Meas_LatCW_left as a double


% --- Executes during object creation, after setting all properties.
function Meas_LatCW_left_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_LatCW_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_FTangle_right_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_FTangle_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_FTangle_right as text
%        str2double(get(hObject,'String')) returns contents of Meas_FTangle_right as a double


% --- Executes during object creation, after setting all properties.
function Meas_FTangle_right_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_FTangle_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_MedJS_right_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_MedJS_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_MedJS_right as text
%        str2double(get(hObject,'String')) returns contents of Meas_MedJS_right as a double


% --- Executes during object creation, after setting all properties.
function Meas_MedJS_right_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_MedJS_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_LatJS_right_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_LatJS_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_LatJS_right as text
%        str2double(get(hObject,'String')) returns contents of Meas_LatJS_right as a double


% --- Executes during object creation, after setting all properties.
function Meas_LatJS_right_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_LatJS_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_MedCW_right_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_MedCW_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_MedCW_right as text
%        str2double(get(hObject,'String')) returns contents of Meas_MedCW_right as a double


% --- Executes during object creation, after setting all properties.
function Meas_MedCW_right_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_MedCW_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_LatCW_right_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_LatCW_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_LatCW_right as text
%        str2double(get(hObject,'String')) returns contents of Meas_LatCW_right as a double


% --- Executes during object creation, after setting all properties.
function Meas_LatCW_right_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_LatCW_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_Cdist_left_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_Cdist_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_Cdist_left as text
%        str2double(get(hObject,'String')) returns contents of Meas_Cdist_left as a double


% --- Executes during object creation, after setting all properties.
function Meas_Cdist_left_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_Cdist_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_Cdist_right_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_Cdist_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_Cdist_right as text
%        str2double(get(hObject,'String')) returns contents of Meas_Cdist_right as a double


% --- Executes during object creation, after setting all properties.
function Meas_Cdist_right_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_Cdist_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_TotalCW_left_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_TotalCW_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_TotalCW_left as text
%        str2double(get(hObject,'String')) returns contents of Meas_TotalCW_left as a double


% --- Executes during object creation, after setting all properties.
function Meas_TotalCW_left_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_TotalCW_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_TotalCW_right_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_TotalCW_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_TotalCW_right as text
%        str2double(get(hObject,'String')) returns contents of Meas_TotalCW_right as a double


% --- Executes during object creation, after setting all properties.
function Meas_TotalCW_right_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_TotalCW_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Pat_ID_Callback(hObject, eventdata, handles)
% hObject    handle to Pat_ID (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Pat_ID as text
%        str2double(get(hObject,'String')) returns contents of Pat_ID as a double


% --- Executes during object creation, after setting all properties.
function Pat_ID_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Pat_ID (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Pat_age_Callback(hObject, eventdata, handles)
% hObject    handle to Pat_age (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Pat_age as text
%        str2double(get(hObject,'String')) returns contents of Pat_age as a double


% --- Executes during object creation, after setting all properties.
function Pat_age_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Pat_age (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Pat_weight_Callback(hObject, eventdata, handles)
% hObject    handle to Pat_weight (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Pat_weight as text
%        str2double(get(hObject,'String')) returns contents of Pat_weight as a double


% --- Executes during object creation, after setting all properties.
function Pat_weight_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Pat_weight (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Pat_height_Callback(hObject, eventdata, handles)
% hObject    handle to Pat_height (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Pat_height as text
%        str2double(get(hObject,'String')) returns contents of Pat_height as a double


% --- Executes during object creation, after setting all properties.
function Pat_height_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Pat_height (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Button_swap_sides.
function Button_swap_sides_Callback(hObject, eventdata, handles)
% hObject    handle to Button_swap_sides (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% dicomwrite(handles.Iref,'001')
I = handles.Iorighef;
rightIc = handles.rightIc;
       
testI = I(rightIc(2):rightIc(2)+rightIc(4), rightIc(1):rightIc(1)+rightIc(3));
% Icroptop = round(handles.right_JS_loc-handles.JSmargin);
% Icropbottom = round(handles.right_JS_loc+handles.JSmargin); 
% testI = testI(Icroptop:Icropbottom,:);
testIf = imgaussfilt(testI,6);
testI = testI./max(testI(:));


BW = edge(testIf,'Canny');
% SE = strel('square',5);
% SE2= strel('square',4);
% BW = imdilate(BW,SE);
% BW = imerode(BW,SE2);
% BW = bwskel(BW);
% BW = keep_biggest(BW,20);
% BW = bwlabel(BW);

B = imoverlay(testI,BW,'red');
figure(1)
imshowpair(testIf,B,'montage')


% --- Executes on button press in Button_tweak_left.
function Button_tweak_left_Callback(hObject, eventdata, handles)
% hObject    handle to Button_tweak_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'Tweak_left');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);


% --- Executes on button press in Button_tweak_right.
function Button_tweak_right_Callback(hObject, eventdata, handles)
% hObject    handle to Button_tweak_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'Tweak_right');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);

% --- Executes on button press in Button_FTtibia_left.
function Button_FTtibia_left_Callback(hObject, eventdata, handles)
% hObject    handle to Button_FTtibia_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'FTtibia_left');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);


% --- Executes on button press in Button_FTtibia_right.
function Button_FTtibia_right_Callback(hObject, eventdata, handles)
% hObject    handle to Button_FTtibia_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'FTtibia_right');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);

% --- Executes on button press in Button_JS_left.
function Button_JS_left_Callback(hObject, eventdata, handles)
% hObject    handle to Button_JS_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'JS_left');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);

% --- Executes on button press in Button_JS_right.
function Button_JS_right_Callback(hObject, eventdata, handles)
% hObject    handle to Button_JS_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'JS_right');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);

% --- Executes on button press in Button_CW_left.
function Button_CW_left_Callback(hObject, eventdata, handles)
% hObject    handle to Button_CW_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'CW_left');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);

% --- Executes on button press in Button_CW_right.
function Button_CW_right_Callback(hObject, eventdata, handles)
% hObject    handle to Button_CW_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'CW_right');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);

% --- Executes on button press in Button_run_automatic.
function Button_run_automatic_Callback(hObject, eventdata, handles)
% hObject    handle to Button_run_automatic (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.Manualedit.JSset_left = 0;
handles.Manualedit.JSset_right = 0;
handles.Manualedit.FTfemur_left = 0;
handles.Manualedit.FTfemur_right = 0;
handles.Manualedit.FTtibia_left = 0;
handles.Manualedit.FTtibia_right = 0;
handles.Manualedit.JS_left = 0;
handles.Manualedit.JS_right = 0;
handles.Manualedit.CW_left = 0;
handles.Manualedit.CW_right = 0;
handles.Manualedit.Tweak_left = 0;
handles.Manualedit.Tweak_right = 0;
handles.Manualedit.Any_right = 0;
handles.Manualedit.Any_left = 0;
handles.Manualedit.Shaftangle_right = 0;
handles.Manualedit.Shaftangle_left = 0;
handles = automatic_analysis(handles);

guidata(hObject, handles);

update_axes(handles);

% --- Executes on button press in Button_JSset_left.
function Button_JSset_left_Callback(hObject, eventdata, handles)
% hObject    handle to Button_JSset_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'JSset_left');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);

% --- Executes on button press in Button_JSset_right.
function Button_JSset_right_Callback(hObject, eventdata, handles)
% hObject    handle to Button_JSset_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'JSset_right');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);

function handles = automatic_analysis(handles)
wb = waitbar(0,'Finding knees...');
nofsteps = 10;
if handles.Manualedit.Tweak_left+handles.Manualedit.Tweak_right == 0
    [handles.rightI, handles.leftI, handles.rightIc, handles.leftIc] = find_left_right(handles.Iorighef,handles.addside,handles.sidesmooth);
end

if ~isnan(handles.rightI)
    if ~handles.Manualedit.Any_left
        waitbar(1/nofsteps,wb,'Finding right knee jointspace...');
        if ~handles.Manualedit.JSset_right
            handles.right_JS_loc = find_JS_location(handles.rightI,handles.JSlocTH,handles.MinWidth);
        end

        waitbar(2/nofsteps,wb,'Defining right knee dimensions...');
        if ~handles.Manualedit.JS_right
            handles.right_JSdimensions = find_JSdimensions2(handles.rightI,handles.right_JS_loc,handles.JSmargin,handles.MinWidth,2,handles.JSdimsmooth,handles.JSlocTH,handles.pixelsize(1), handles.rightIc);
        end

        waitbar(3/nofsteps,wb,'Finding right knee tibia angle...');
        if ~handles.Manualedit.FTtibia_right
            handles.right_tibia_angle = find_tibiaangle(handles.rightI,handles.right_JS_loc,handles.TibiaROI,handles.MinWidth,2,handles.ftanglesmooth, handles.rightIc, handles.right_JSdimensions.LatJScoord, handles.right_JSdimensions.MedJScoord);
        end
        
        waitbar(4/nofsteps,wb,'Finding right knee shaft angle...');
        if ~handles.Manualedit.Shaftangle_right % && ~handles.Manualedit.Any_right
            handles.right_shaftcoords = find_shaft_angle(handles.rightI,handles.right_JS_loc,handles.JSmargin,handles.MinWidth,2,handles.ftanglesmooth,[],handles.rightIc);
        end
    end

    if ~handles.Manualedit.Any_right
        waitbar(5/nofsteps,wb,'Finding left knee jointspace...');
        if ~handles.Manualedit.JSset_left
            handles.left_JS_loc = find_JS_location(handles.leftI,handles.JSlocTH,handles.MinWidth);
        end

        waitbar(6/nofsteps,wb,'Defining left knee dimensions...');
        if ~handles.Manualedit.JS_left
            handles.left_JSdimensions = find_JSdimensions2(handles.leftI,handles.left_JS_loc,handles.JSmargin,handles.MinWidth,1,handles.JSdimsmooth,handles.JSlocTH,handles.pixelsize(1), handles.leftIc);
        end

        waitbar(7/nofsteps,wb,'Finding left knee tibia angle...');
        if ~handles.Manualedit.FTtibia_left 
            handles.left_tibia_angle = find_tibiaangle(handles.leftI,handles.left_JS_loc,handles.TibiaROI,handles.MinWidth,1,handles.ftanglesmooth, handles.leftIc, handles.left_JSdimensions.LatJScoord, handles.left_JSdimensions.MedJScoord);
        end
        
        waitbar(8/nofsteps,wb,'Finding left knee shaft angle...');
        if ~handles.Manualedit.Shaftangle_left % && ~handles.Manualedit.Any_left
            handles.left_shaftcoords = find_shaft_angle(handles.leftI,handles.left_JS_loc,handles.JSmargin,handles.MinWidth,1,handles.ftanglesmooth,[],handles.leftIc);
        end
    end

    if handles.Manualedit.Any_left || handles.Manualedit.Any_right
        waitbar(9/nofsteps,wb,'Updating...');
        handles.Manualedit.Any_left = 0;
        handles.Manualedit.Any_right = 0;
    else
        waitbar(9/nofsteps,wb,'Finalizing...');
    end

    [handles.right_FTANGLE, handles.right_DIMS] = calculate_ftangle(handles.right_JSdimensions.LatJScoord, handles.right_JSdimensions.MedJScoord, handles.right_JSdimensions.Cropimhc, handles.right_tibia_angle.angle_coordinates, handles.right_JSdimensions.CWcoord,handles.right_shaftcoords,2,handles.pixelsize(1));
    [handles.left_FTANGLE, handles.left_DIMS] = calculate_ftangle(handles.left_JSdimensions.MedJScoord, handles.left_JSdimensions.LatJScoord, handles.left_JSdimensions.Cropimhc, handles.left_tibia_angle.angle_coordinates, handles.left_JSdimensions.CWcoord,handles.left_shaftcoords,1,handles.pixelsize(1));
else
    handles.left_tibia_angle.angle_coordinates = NaN;
    handles.left_tibia_angle.edge_coordinates = NaN; 
    handles.right_tibia_angle.angle_coordinates = NaN;
    handles.right_tibia_angle.edge_coordinates = NaN; 
    handles.left_JS_loc = NaN;
    handles.right_JS_loc = NaN;
    handles.left_JSdimensions.LatJScoord = NaN;
    handles.left_JSdimensions.MedJScoord = NaN;
    handles.left_JSdimensions.CWcoord = NaN;    
    handles.left_JSdimensions.Cropimhc = NaN;
    handles.right_JSdimensions.LatJScoord = NaN;
    handles.right_JSdimensions.MedJScoord = NaN;
    handles.right_JSdimensions.CWcoord = NaN;    
    handles.right_JSdimensions.Cropimhc = NaN;
    handles.left_FTANGLE.tibiaangle = NaN;
    handles.left_FTANGLE.femurangle = NaN;
    handles.left_FTANGLE.JScoord = NaN;
    handles.left_FTANGLE.JScoord90 = NaN;
    handles.left_FTANGLE.ftangle = NaN;
    handles.left_FTANGLE.tibia_coord = NaN; 
    handles.left_DIMS.LatJSwidth = NaN;
    handles.left_DIMS.MedJSwidth = NaN;
    handles.left_DIMS.CWwidth = NaN;
    handles.left_DIMS.CWwidth(3) = NaN;
    handles.left_DIMS.CondDist = NaN;
    handles.left_FTANGLE.shaft_angle = NaN;
    handles.left_FTANGLE.shaft_femur_angle = NaN;
    handles.left_FTANGLE.shaft_tibia_angle = NaN;
    handles.left_shaftcoords.femur_coords = NaN;
    handles.left_shaftcoords.tibia_coords = NaN;
    handles.right_FTANGLE.tibiaangle = NaN;
    handles.right_FTANGLE.femurangle = NaN;
    handles.right_FTANGLE.JScoord = NaN;
    handles.right_FTANGLE.JScoord90 = NaN;
    handles.right_FTANGLE.ftangle = NaN;
    handles.right_FTANGLE.tibia_coord = NaN; 
    handles.right_DIMS.LatJSwidth = NaN;
    handles.right_DIMS.MedJSwidth = NaN;
    handles.right_DIMS.CWwidth = NaN;
    handles.right_DIMS.CWwidth(3) = NaN;
    handles.right_DIMS.CondDist = NaN;
    handles.right_FTANGLE.shaft_angle = NaN;
    handles.right_FTANGLE.shaft_femur_angle = NaN;
    handles.right_FTANGLE.shaft_tibia_angle = NaN;
    handles.right_shaftcoords.femur_coords = NaN;
    handles.right_shaftcoords.tibia_coords = NaN;
end
waitbar(10/nofsteps,wb,'Analysis ready!');
pause(0.5);
close(wb);

function load_patient_data(handles)
load('patient_data.mat');
id = handles.dcminfo.PatientID;

I = find(patient_data(:,1) == str2double(id));

set(handles.Pat_ID,'String',id);
set(handles.Pat_age,'String',num2str(patient_data(I,3)));
set(handles.Pat_weight,'String',num2str(patient_data(I,4)));
set(handles.Pat_height,'String',num2str(patient_data(I,5)));
if patient_data(I,2) == 1
    set(handles.Pat_male,'Value',1);
elseif patient_data(I,2) == 2
    set(handles.Pat_female,'Value',1);
end

function update_contrast(handles)
handles;


function update_axes(handles)
% try
axes(handles.Main_axes)
if get(handles.Show_histeq,'Value')
    imagesc(handles.Iorighef)
else
    imagesc(handles.Iorig)
end
axis image
colormap(gray)
hold on
try
rectangle('Position',handles.rightIc,'Edgecolor','b')
rectangle('Position',handles.leftIc,'Edgecolor','r')


line([handles.rightIc(1) handles.rightIc(3)+handles.rightIc(1)], [handles.right_JS_loc handles.right_JS_loc],'LineStyle','--','Color','y')
line([handles.leftIc(1) handles.leftIc(3)+handles.leftIc(1)], [handles.left_JS_loc handles.left_JS_loc],'LineStyle','--','Color','y')

if ~any(isnan(handles.right_tibia_angle.edge_coordinates(:)))
    plot(handles.right_tibia_angle.edge_coordinates(1,:), handles.right_tibia_angle.edge_coordinates(2,:),'kx');
end
if ~any(isnan(handles.right_tibia_angle.angle_coordinates(:)))
    plot(handles.right_tibia_angle.angle_coordinates(1,:), handles.right_tibia_angle.angle_coordinates(2,:),'ko');
end
if ~any(isnan(handles.right_FTANGLE.JScoord(:)))
    line(handles.right_FTANGLE.JScoord(1,:), handles.right_FTANGLE.JScoord(2,:),'LineStyle','--','Color','b','LineWidth',1)
end
if ~any(isnan(handles.right_JSdimensions.MedJScoord(:)))
    line(handles.right_JSdimensions.MedJScoord(1,:), handles.right_JSdimensions.MedJScoord(2,:),'Color','g','LineWidth',2)
end
if ~any(isnan(handles.right_JSdimensions.LatJScoord(:)))
    line(handles.right_JSdimensions.LatJScoord(1,:), handles.right_JSdimensions.LatJScoord(2,:),'Color','r','LineWidth',2)
end
if ~any(isnan(handles.right_FTANGLE.JScoord90(:)))
    line(handles.right_FTANGLE.JScoord90(1,:), handles.right_FTANGLE.JScoord90(2,:),'Color','b','LineWidth',2)
end
if ~any(isnan(handles.right_FTANGLE.tibia_coord(:)))
    line(handles.right_FTANGLE.tibia_coord(1,:), handles.right_FTANGLE.tibia_coord(2,:),'Color','g','LineWidth',2)
end
if ~any(isnan(handles.right_shaftcoords.femur_coords(:)))
    line(handles.right_shaftcoords.femur_coords(1,:), handles.right_shaftcoords.femur_coords(2,:),'LineStyle','--','Color','c','LineWidth',2)
end
if ~any(isnan(handles.right_shaftcoords.tibia_coords(:)))
    line(handles.right_shaftcoords.tibia_coords(1,:), handles.right_shaftcoords.tibia_coords(2,:),'LineStyle','--','Color','m','LineWidth',2)
end

if ~any(isnan(handles.left_tibia_angle.edge_coordinates(:)))
    plot(handles.left_tibia_angle.edge_coordinates(1,:), handles.left_tibia_angle.edge_coordinates(2,:),'kx');
end
if ~any(isnan(handles.left_tibia_angle.angle_coordinates(:)))
    plot(handles.left_tibia_angle.angle_coordinates(1,:), handles.left_tibia_angle.angle_coordinates(2,:),'ko');
end
if ~any(isnan(handles.left_FTANGLE.JScoord(:)))
    line(handles.left_FTANGLE.JScoord(1,:), handles.left_FTANGLE.JScoord(2,:),'LineStyle','--','Color','b','LineWidth',1)
end
if ~any(isnan(handles.left_JSdimensions.MedJScoord(:)))
    line(handles.left_JSdimensions.MedJScoord(1,:), handles.left_JSdimensions.MedJScoord(2,:),'Color','g','LineWidth',2)
end
if ~any(isnan(handles.left_JSdimensions.LatJScoord(:)))
    line(handles.left_JSdimensions.LatJScoord(1,:), handles.left_JSdimensions.LatJScoord(2,:),'Color','r','LineWidth',2)
end
if ~any(isnan(handles.left_FTANGLE.JScoord90(:)))
    line(handles.left_FTANGLE.JScoord90(1,:), handles.left_FTANGLE.JScoord90(2,:),'Color','b','LineWidth',2)
end
if ~any(isnan(handles.left_FTANGLE.tibia_coord(:)))
    line(handles.left_FTANGLE.tibia_coord(1,:), handles.left_FTANGLE.tibia_coord(2,:),'Color','g','LineWidth',2)
end
if ~any(isnan(handles.left_shaftcoords.femur_coords(:)))
    line(handles.left_shaftcoords.femur_coords(1,:), handles.left_shaftcoords.femur_coords(2,:),'LineStyle','--','Color','c','LineWidth',2)
end
if ~any(isnan(handles.left_shaftcoords.tibia_coords(:)))
    line(handles.left_shaftcoords.tibia_coords(1,:), handles.left_shaftcoords.tibia_coords(2,:),'LineStyle','--','Color','m','LineWidth',2)
end

if ~any(isnan(handles.right_JSdimensions.CWcoord(:)))
    line(handles.right_JSdimensions.CWcoord(1,1:2), handles.right_JSdimensions.CWcoord(2,1:2),'Color','r','LineWidth',2);
    line(handles.right_JSdimensions.CWcoord(1,2:3), handles.right_JSdimensions.CWcoord(2,2:3),'Color','g','LineWidth',2);
    plot(handles.right_JSdimensions.CWcoord(1,2), handles.right_JSdimensions.CWcoord(2,2),'ko')
end

if ~any(isnan(handles.left_JSdimensions.CWcoord(:)))
    line(handles.left_JSdimensions.CWcoord(1,1:2), handles.left_JSdimensions.CWcoord(2,1:2),'Color','r','LineWidth',2);
    line(handles.left_JSdimensions.CWcoord(1,2:3), handles.left_JSdimensions.CWcoord(2,2:3),'Color','g','LineWidth',2);
    plot(handles.left_JSdimensions.CWcoord(1,2), handles.left_JSdimensions.CWcoord(2,2),  'ko')
end
catch
    disp('Plotting error');
end
hold off


set(handles.Meas_FTangle_right,'String',num2str(handles.right_FTANGLE.ftangle));
set(handles.Meas_FTangle_left,'String',num2str(handles.left_FTANGLE.ftangle));
set(handles.Meas_shaftangle_right,'String',num2str(handles.right_FTANGLE.shaft_angle));
set(handles.Meas_shaftangle_left,'String',num2str(handles.left_FTANGLE.shaft_angle));
set(handles.Meas_MedJS_right,'String',num2str(handles.right_DIMS.MedJSwidth));
set(handles.Meas_MedJS_left,'String',num2str(handles.left_DIMS.MedJSwidth));
set(handles.Meas_LatJS_right,'String',num2str(handles.right_DIMS.LatJSwidth));
set(handles.Meas_LatJS_left,'String',num2str(handles.left_DIMS.LatJSwidth));
set(handles.Meas_Cdist_right,'String',num2str(handles.right_DIMS.CondDist));
set(handles.Meas_Cdist_left,'String',num2str(handles.left_DIMS.CondDist));
set(handles.Meas_MedCW_right,'String',num2str(handles.right_DIMS.CWwidth(2)));
set(handles.Meas_MedCW_left,'String',num2str(handles.left_DIMS.CWwidth(2)));
set(handles.Meas_LatCW_right,'String',num2str(handles.right_DIMS.CWwidth(1)));
set(handles.Meas_LatCW_left,'String',num2str(handles.left_DIMS.CWwidth(1)));
set(handles.Meas_TotalCW_right,'String',num2str(handles.right_DIMS.CWwidth(3)));
set(handles.Meas_TotalCW_left,'String',num2str(handles.left_DIMS.CWwidth(3)));
% catch
%     disp('some error')
% end

function handles = update_measures(handles,type)
switch type
    case 'JSset_left'
%         disp('JSset_left');
        ef = figure('Name','Edit left JS location','units','normalized','outerposition',[0 0 1 1]);
        imagesc(handles.leftI)
        axis image
        colormap(gray)
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h = imline(gca,[1 handles.leftIc(3)], [handles.left_JS_loc handles.left_JS_loc]);
            setColor(h,'yellow');
            fcn = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            setPositionConstraintFcn(h,fcn);
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end              
        hold off
        position = getPosition(h); 
        handles.left_JS_loc = position(1,2);
        close(ef)
        
        handles.Manualedit.Any_left = 1;
        handles.Manualedit.Tweak_left = 1;
        handles.Manualedit.JSset_left = 1;       
        handles.Manualedit.FTtibia_left = 0;
        handles.Manualedit.JS_left = 0;
        handles.Manualedit.CW_left = 0;
        
    case 'JSset_right'
%         disp('JSset_right');
        ef = figure('Name','Edit right JS location','units','normalized','outerposition',[0 0 1 1]);
        imagesc(handles.rightI)
        axis image
        colormap(gray)
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h = imline(gca,[1 handles.rightIc(3)], [handles.right_JS_loc handles.right_JS_loc]);
            setColor(h,'yellow');
            fcn = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            setPositionConstraintFcn(h,fcn);
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end              
        hold off
        position = getPosition(h);
        handles.right_JS_loc = position(1,2);
        close(ef)
        
        handles.Manualedit.Any_right = 1;
        handles.Manualedit.Tweak_right = 1;
        handles.Manualedit.JSset_right = 1;       
        handles.Manualedit.FTtibia_right = 0;
        handles.Manualedit.JS_right = 0;
        handles.Manualedit.CW_right = 0;
        
    case 'FTtibia_left'
%         disp('FTtibia_left');
        plotdata = handles.left_tibia_angle.edge_coordinates;
         if isnan(plotdata(1,3))
            plotdata(1,3) = plotdata(1,1);
            plotdata(1,4) = plotdata(1,2);
        end
        plotdata(1,:) = plotdata(1,:)-handles.leftIc(1);
        ef = figure('Name','Edit left tibia angle','units','normalized','outerposition',[0 0 1 1]);
        imagesc(handles.leftI)
        axis image
        colormap(gray)
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h1 = impoint(gca,plotdata(:,1)');
            h2 = impoint(gca,plotdata(:,2)');
            h3 = impoint(gca,plotdata(:,3)');
            h4 = impoint(gca,plotdata(:,4)');
            setColor(h1,'red');
            setColor(h2,'red');
            setColor(h3,'red');
            setColor(h4,'red');
            fcn1 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,1) plotdata(2,1)]);
            fcn2 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,2) plotdata(2,2)]);
            fcn3 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,3) plotdata(2,3)]);
            fcn4 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,4) plotdata(2,4)]);
            setPositionConstraintFcn(h1,fcn1);
            setPositionConstraintFcn(h2,fcn2);
            setPositionConstraintFcn(h3,fcn3);
            setPositionConstraintFcn(h4,fcn4);
            hold off
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end
        position1 = getPosition(h1);
        position2 = getPosition(h2);
        position3 = getPosition(h3);
        position4 = getPosition(h4);
        updated_pos = round([position1' position2' position3' position4']);
        updated_pos(1,:) = updated_pos(1,:)+handles.leftIc(1);        
        handles.left_tibia_angle.edge_coordinates = updated_pos;
        handles.left_tibia_angle.angle_coordinates(1,:) = round([mean(updated_pos(1,1:2)) mean(updated_pos(1,3:4))]);
        close(ef)
        
        handles.Manualedit.Any_left = 1;
        handles.Manualedit.Tweak_left = 1;
        handles.Manualedit.JSset_left = 1;
        handles.Manualedit.JS_left = 1;
        handles.Manualedit.FTtibia_left = 1;        
        handles.Manualedit.CW_left = 0;
      
    case 'FTtibia_right'
%         disp('FTtibia_right');
        plotdata = handles.right_tibia_angle.edge_coordinates;
        if isnan(plotdata(1,3))
            plotdata(1,3) = plotdata(1,1);
            plotdata(1,4) = plotdata(1,2);
        end
        plotdata(1,:) = plotdata(1,:)-handles.rightIc(1);
        ef = figure('Name','Edit right tibia angle','units','normalized','outerposition',[0 0 1 1]);
        imagesc(handles.rightI)
        axis image
        colormap(gray)
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h1 = impoint(gca,plotdata(:,1)');
            h2 = impoint(gca,plotdata(:,2)');
            h3 = impoint(gca,plotdata(:,3)');
            h4 = impoint(gca,plotdata(:,4)');
            setColor(h1,'red');
            setColor(h2,'red');
            setColor(h3,'red');
            setColor(h4,'red');
            fcn1 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,1) plotdata(2,1)]);
            fcn2 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,2) plotdata(2,2)]);
            fcn3 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,3) plotdata(2,3)]);
            fcn4 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,4) plotdata(2,4)]);
            setPositionConstraintFcn(h1,fcn1);
            setPositionConstraintFcn(h2,fcn2);
            setPositionConstraintFcn(h3,fcn3);
            setPositionConstraintFcn(h4,fcn4);
            hold off
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end
        position1 = getPosition(h1);
        position2 = getPosition(h2);
        position3 = getPosition(h3);
        position4 = getPosition(h4);
        updated_pos = round([position1' position2' position3' position4']);
        updated_pos(1,:) = updated_pos(1,:)+handles.rightIc(1);
        handles.right_tibia_angle.edge_coordinates = updated_pos;
        handles.right_tibia_angle.angle_coordinates(1,:) = round([mean(updated_pos(1,1:2)) mean(updated_pos(1,3:4))]);
        close(ef)
        
        handles.Manualedit.Any_right = 1;
        handles.Manualedit.Tweak_right = 1;
        handles.Manualedit.JSset_right = 1;
        handles.Manualedit.JS_right = 1;
        handles.Manualedit.FTtibia_right = 1;        
        handles.Manualedit.CW_right = 0;
        
    case 'JS_left'
%         disp('JS_left');

        if ~isnan(handles.left_JSdimensions.MedJScoord)
            plotdatamed = handles.left_JSdimensions.MedJScoord;
            plotdatalat = handles.left_JSdimensions.LatJScoord;   
        else
            st = handles.leftIc(1)+handles.leftIc(3)*0.1;
            se = handles.leftIc(1)+handles.leftIc(3)*0.9;
            ct = round(2/handles.pixelsize(1));
            plotdatamed = [st st; handles.left_JS_loc-ct handles.left_JS_loc+ct];
            plotdatalat = [se se; handles.left_JS_loc-ct handles.left_JS_loc+ct];
        end
        plotdatamed(1,:) = plotdatamed(1,:)-handles.leftIc(1);
        plotdatalat(1,:) = plotdatalat(1,:)-handles.leftIc(1);
        
        Icroptop = round(handles.left_JS_loc-handles.JSmargin);
        Icropbottom = round(handles.left_JS_loc+handles.JSmargin);
        plotdatamed(2,:) = plotdatamed(2,:)-Icroptop;
        plotdatalat(2,:) = plotdatalat(2,:)-Icroptop;
        plotIm = handles.leftI(Icroptop:Icropbottom,:);
        
        ef = figure('Name','Edit left jointspaces','units','normalized','outerposition',[0 0 1 1]);
        imagesc(plotIm)
        axis image
        colormap(gray)
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h1 = imline(gca,plotdatamed');
            h2 = imline(gca,plotdatalat');
            setColor(h1,'green');
            setColor(h2,'red');
            fcn1 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            fcn2 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            setPositionConstraintFcn(h1,fcn1);
            setPositionConstraintFcn(h2,fcn2);
            hold off
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end
        position1 = getPosition(h1);
        position2 = getPosition(h2);
        updatedpos1 = round(position1');
        updatedpos2 = round(position2');
        updatedpos1(1,:) = updatedpos1(1,:)+handles.leftIc(1);
        updatedpos2(1,:) = updatedpos2(1,:)+handles.leftIc(1);
        updatedpos1(2,:) = updatedpos1(2,:)+Icroptop;
        updatedpos2(2,:) = updatedpos2(2,:)+Icroptop;
        handles.left_JSdimensions.MedJScoord = updatedpos1;
        handles.left_JSdimensions.LatJScoord = updatedpos2;
        
        if (~isnan(handles.left_tibia_angle.angle_coordinates))
            tibplat = max([updatedpos1(2,:) updatedpos2(2,:)]);
            bs = tibplat+handles.TibiaROI(1);
            be = tibplat+handles.TibiaROI(2);
            handles.left_tibia_angle.angle_coordinates(2,:) = [bs be];
            handles.left_tibia_angle.edge_coordinates(2,:) = [bs bs be be];
        end
        
        close(ef)
        
        handles.Manualedit.Any_left = 1;
        handles.Manualedit.Tweak_left = 1;
        handles.Manualedit.JSset_left = 1;
        handles.Manualedit.JS_left = 1;        
        handles.Manualedit.CW_left = 0;
        
    case 'JS_right'
%         disp('JS_right');
        if ~isnan(handles.right_JSdimensions.MedJScoord)
            plotdatamed = handles.right_JSdimensions.MedJScoord;
            plotdatalat = handles.right_JSdimensions.LatJScoord;   
        else
            st = handles.rightIc(1)+handles.rightIc(3)*0.1;
            se = handles.rightIc(1)+handles.rightIc(3)*0.9;
            ct = round(2/handles.pixelsize(1));
            plotdatalat = [st st; handles.right_JS_loc-ct handles.right_JS_loc+ct];
            plotdatamed = [se se; handles.right_JS_loc-ct handles.right_JS_loc+ct];
        end

        plotdatamed(1,:) = plotdatamed(1,:)-handles.rightIc(1);
        plotdatalat(1,:) = plotdatalat(1,:)-handles.rightIc(1);
        
        Icroptop = round(handles.right_JS_loc-handles.JSmargin);
        Icropbottom = round(handles.right_JS_loc+handles.JSmargin);
        plotdatamed(2,:) = plotdatamed(2,:)-Icroptop;
        plotdatalat(2,:) = plotdatalat(2,:)-Icroptop;
        plotIm = handles.rightI(Icroptop:Icropbottom,:);
        
        ef = figure('Name','Edit right jointspaces','units','normalized','outerposition',[0 0 1 1]);
        imagesc(plotIm)
        axis image
        colormap(gray)
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h1 = imline(gca,plotdatamed');
            h2 = imline(gca,plotdatalat');
            setColor(h1,'green');
            setColor(h2,'red');
            fcn1 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            fcn2 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            setPositionConstraintFcn(h1,fcn1);
            setPositionConstraintFcn(h2,fcn2);
            hold off
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end
        position1 = getPosition(h1);
        position2 = getPosition(h2);
        updatedpos1 = round(position1');
        updatedpos2 = round(position2');
        updatedpos1(1,:) = updatedpos1(1,:)+handles.rightIc(1);
        updatedpos2(1,:) = updatedpos2(1,:)+handles.rightIc(1);
        updatedpos1(2,:) = updatedpos1(2,:)+Icroptop;
        updatedpos2(2,:) = updatedpos2(2,:)+Icroptop;
        handles.right_JSdimensions.MedJScoord = updatedpos1;
        handles.right_JSdimensions.LatJScoord = updatedpos2;
        
        if (~isnan(handles.right_tibia_angle.angle_coordinates))
            tibplat = max([updatedpos1(2,:) updatedpos2(2,:)]);
            bs = tibplat+handles.TibiaROI(1);
            be = tibplat+handles.TibiaROI(2);
            handles.right_tibia_angle.angle_coordinates(2,:) = [bs be];
            handles.right_tibia_angle.edge_coordinates(2,:) = [bs bs be be];
        end
        
        close(ef)
        
        handles.Manualedit.Any_right = 1;
        handles.Manualedit.Tweak_right = 1;
        handles.Manualedit.JSset_right = 1;
        handles.Manualedit.JS_right = 1;      
        handles.Manualedit.CW_right = 0;
        
    case 'CW_left'
%         disp('CW_left');
        if ~isnan(handles.left_JSdimensions.CWcoord)
            plotdata = handles.left_JSdimensions.CWcoord;
            allowy = 0;
        else
            allowy = 1;
            yg = handles.left_JS_loc-round(6/handles.pixelsize(1));
            xg1 = handles.leftIc(1)+handles.leftIc(3)*0.1;
            xg2 = handles.leftIc(1)+handles.leftIc(3)*0.5;
            xg3 = handles.leftIc(1)+handles.leftIc(3)*0.9;
            plotdata = [xg3 xg2 xg1; yg yg yg];
        end
        
        plotdata(1,:) = plotdata(1,:)-handles.leftIc(1);
        ef = figure('Name','Edit left condyle widths','units','normalized','outerposition',[0 0 1 1]);
        imagesc(handles.leftI)
        axis image
        colormap(gray)
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h1 = impoint(gca,plotdata(:,1)');
            h2 = impoint(gca,plotdata(:,2)');
            h3 = impoint(gca,plotdata(:,3)');
            setColor(h1,'red');
            setColor(h2,'black');
            setColor(h3,'green');
            fcn1 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,2) plotdata(2,2)]);
            fcn2 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,2) plotdata(2,2)]);
            fcn3 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,2) plotdata(2,2)]);
            setPositionConstraintFcn(h1,fcn1);
%             if ~allowy
%                 setPositionConstraintFcn(h2,fcn2);
%             end
            setPositionConstraintFcn(h3,fcn3);
            hold off
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end
        position1 = getPosition(h1);
        position2 = getPosition(h2);
        position3 = getPosition(h3);
        updated_pos = round([position1(1) position2(1) position3(1); position2(2) position2(2) position2(2)]);
        updated_pos(1,:) = updated_pos(1,:)+handles.leftIc(1);
        handles.left_JSdimensions.CWcoord = updated_pos; 
        handles.left_JSdimensions.Cropimhc = [updated_pos(1,1) updated_pos(1,3)];
        close(ef)
        
        handles.Manualedit.Any_left = 1;
        handles.Manualedit.Tweak_left = 1;
        handles.Manualedit.JSset_left = 1;
        handles.Manualedit.JS_left = 1;
        handles.Manualedit.FTtibia_left = 1;        
        handles.Manualedit.CW_left = 1;
        
    case 'CW_right'
%         disp('CW_right');
        if ~isnan(handles.right_JSdimensions.CWcoord)
            plotdata = handles.right_JSdimensions.CWcoord;
            allowy = 0;
        else
            allowy = 1;
            yg = handles.right_JS_loc-round(6/handles.pixelsize(1));
            xg1 = handles.rightIc(1)+handles.rightIc(3)*0.1;
            xg2 = handles.rightIc(1)+handles.rightIc(3)*0.5;
            xg3 = handles.rightIc(1)+handles.rightIc(3)*0.9;
            plotdata = [xg1 xg2 xg3; yg yg yg];
        end
        plotdata(1,:) = plotdata(1,:)-handles.rightIc(1);
        ef = figure('Name','Edit right condyle widhts','units','normalized','outerposition',[0 0 1 1]);
        imagesc(handles.rightI)
        axis image
        colormap(gray)
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h1 = impoint(gca,plotdata(:,1)');
            h2 = impoint(gca,plotdata(:,2)');
            h3 = impoint(gca,plotdata(:,3)');
            setColor(h1,'red');
            setColor(h2,'black');
            setColor(h3,'green');
            fcn1 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,2) plotdata(2,2)]);
            fcn2 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,2) plotdata(2,2)]);
            fcn3 = makeConstrainToRectFcn('impoint',get(gca,'XLim'),[plotdata(2,2) plotdata(2,2)]);
            setPositionConstraintFcn(h1,fcn1);
%             if ~allowy
%                 setPositionConstraintFcn(h2,fcn2);
%             end
            setPositionConstraintFcn(h3,fcn3);
            hold off
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end
        position1 = getPosition(h1);
        position2 = getPosition(h2);
        position3 = getPosition(h3);
        updated_pos = round([position1(1) position2(1) position3(1); position2(2) position2(2) position2(2)]);
        updated_pos(1,:) = updated_pos(1,:)+handles.rightIc(1);
        handles.right_JSdimensions.CWcoord = updated_pos;
        handles.right_JSdimensions.Cropimhc = [updated_pos(1,1) updated_pos(1,3)];
        close(ef)
        
        handles.Manualedit.Any_right = 1;
        handles.Manualedit.Tweak_right = 1;
        handles.Manualedit.JSset_right = 1;
        handles.Manualedit.JS_right = 1;
        handles.Manualedit.FTtibia_right = 1;        
        handles.Manualedit.CW_right = 1;
        
    case 'Shaftangle_right'
%         disp('Shaftangle_left');

        if ~isnan(handles.right_shaftcoords.femur_coords)
            plotdatafemur = handles.right_shaftcoords.femur_coords;
        else
            st = handles.rightIc(1)+handles.rightIc(3)*0.5;
            plotdatafemur = [st st; 1 handles.right_JS_loc];
        end
        
        if ~isnan(handles.right_shaftcoords.tibia_coords)
            plotdatatibia = handles.right_shaftcoords.tibia_coords;
        else
            st = handles.rightIc(1)+handles.rightIc(3)*0.5;
            plotdatatibia = [st st; handles.right_JS_loc size(handles.rightI,1)];
        end
        
        
        plotdatafemur(1,:) = plotdatafemur(1,:)-handles.rightIc(1);
        plotdatafemur(2,1) = 30;
        plotdatafemur(2,2) = handles.right_JS_loc-30;
        plotdatatibia(1,:) = plotdatatibia(1,:)-handles.rightIc(1);
        plotdatatibia(2,2) = size(handles.rightI,1)-30;
        plotdatatibia(2,1) = handles.right_JS_loc+30;
        
        plotIm = handles.rightI;
        
        ef = figure('Name','Edit left shaft angle','units','normalized','outerposition',[0 0 1 1]);
        imagesc(plotIm)
        axis image
        colormap(gray)
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h1 = imline(gca,plotdatafemur');
            h2 = imline(gca,plotdatatibia');
            setColor(h1,'green');
            setColor(h2,'red');
            fcn1 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            fcn2 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            setPositionConstraintFcn(h1,fcn1);
            setPositionConstraintFcn(h2,fcn2);
            hold off
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end
        position1 = getPosition(h1);
        position2 = getPosition(h2);
        updatedpos1 = round(position1');
        updatedpos2 = round(position2');
        updatedpos1(1,:) = updatedpos1(1,:)+handles.rightIc(1);
        updatedpos2(1,:) = updatedpos2(1,:)+handles.rightIc(1);
        handles.right_shaftcoords.femur_coords = updatedpos1;
        handles.right_shaftcoords.tibia_coords = updatedpos2;
        close(ef)
        
        handles.Manualedit.Any_right = 1;
        handles.Manualedit.Any_left= 1;
        handles.Manualedit.Tweak_right = 1;
        handles.Manualedit.Shaftangle_right = 1;
        
    case 'Shaftangle_left'
%                 disp('Shaftangle_left');

        if ~isnan(handles.left_shaftcoords.femur_coords)
            plotdatafemur = handles.left_shaftcoords.femur_coords;
        else
            st = handles.leftIc(1)+handles.leftIc(3)*0.5;
            plotdatafemur = [st st; 1 handles.left_JS_loc];
        end
        
        if ~isnan(handles.left_shaftcoords.tibia_coords)
            plotdatatibia = handles.left_shaftcoords.tibia_coords;
        else
            st = handles.leftIc(1)+handles.leftIc(3)*0.5;
            plotdatatibia = [st st; handles.left_JS_loc size(handles.leftI,1)];
        end
        
        
        plotdatafemur(1,:) = plotdatafemur(1,:)-handles.leftIc(1);
        plotdatafemur(2,1) = 30;
        plotdatafemur(2,2) = handles.left_JS_loc-30;
        plotdatatibia(1,:) = plotdatatibia(1,:)-handles.leftIc(1);
        plotdatatibia(2,2) = size(handles.leftI,1)-30;
        plotdatatibia(2,1) = handles.left_JS_loc+30;
        
        plotIm = handles.leftI;
        
        ef = figure('Name','Edit left shaft angle','units','normalized','outerposition',[0 0 1 1]);
        imagesc(plotIm)
        axis image
        colormap(gray)
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h1 = imline(gca,plotdatafemur');
            h2 = imline(gca,plotdatatibia');
            setColor(h1,'green');
            setColor(h2,'red');
            fcn1 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            fcn2 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            setPositionConstraintFcn(h1,fcn1);
            setPositionConstraintFcn(h2,fcn2);
            hold off
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end
        position1 = getPosition(h1);
        position2 = getPosition(h2);
        updatedpos1 = round(position1');
        updatedpos2 = round(position2');
        updatedpos1(1,:) = updatedpos1(1,:)+handles.leftIc(1);
        updatedpos2(1,:) = updatedpos2(1,:)+handles.leftIc(1);
        handles.left_shaftcoords.femur_coords = updatedpos1;
        handles.left_shaftcoords.tibia_coords = updatedpos2;
        close(ef)
        
        handles.Manualedit.Any_left = 1;
        handles.Manualedit.Any_right = 1;
        handles.Manualedit.Tweak_left = 1;
        handles.Manualedit.Shaftangle_left = 1;
        
    case 'Tweak_left'
        %disp('Tweak_left');
        plotdataleft = handles.leftIc(1);
        plotdataright = handles.leftIc(1)+handles.leftIc(3);
        ymin = handles.leftIc(2);
        ymax = handles.leftIc(4);
      
        ef = figure('Name','Tweak left knee','units','normalized','outerposition',[0 0 1 1]);
        imagesc(handles.Iorighef)
        axis image
        colormap(gray)     
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h1 = imline(gca,[plotdataleft plotdataleft], [ymin ymax]);
            h2 = imline(gca,[plotdataright plotdataright], [ymin ymax]);
            setColor(h1,'red');
            setColor(h2,'red');
            fcn1 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            fcn2 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            setPositionConstraintFcn(h1,fcn1);
            setPositionConstraintFcn(h2,fcn2);
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end              
        hold off
        position1 = round(getPosition(h1));
        position2 = round(getPosition(h2));
        handles.leftIc = [position1(1) ymin position2(1)-position1(1) ymax];
        
        handles.leftI = handles.Iorighef(ymin:ymax,position1(1):position2(1));
        close(ef)
        
        handles.Manualedit.Any_left = 1;
        handles.Manualedit.Tweak_left = 1;
        
    case 'Tweak_right'
        %disp('Tweak_right'); 
        plotdataleft = handles.rightIc(1);
        plotdataright = handles.rightIc(1)+handles.rightIc(3);
        ymin = handles.rightIc(2);
        ymax = handles.rightIc(4);
      
        ef = figure('Name','Tweak left knee','units','normalized','outerposition',[0 0 1 1]);
        imagesc(handles.Iorighef)
        axis image
        colormap(gray)     
        title('Press [enter] when ready')
        hold on
        val = 1000;
        while val == 1000
            h1 = imline(gca,[plotdataleft plotdataleft], [ymin ymax]);
            h2 = imline(gca,[plotdataright plotdataright], [ymin ymax]);
            setColor(h1,'red');
            setColor(h2,'red');
            fcn1 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            fcn2 = makeConstrainToRectFcn('imline',get(gca,'XLim'),get(gca,'YLim'));
            setPositionConstraintFcn(h1,fcn1);
            setPositionConstraintFcn(h2,fcn2);
            pause
            val = double(get(ef,'CurrentCharacter'));
            if val ~= 13
                val = 1000;
            end
        end              
        hold off
        position1 = round(getPosition(h1));
        position2 = round(getPosition(h2));
        handles.rightIc = [position1(1) ymin position2(1)-position1(1) ymax];
        
        handles.rightI = handles.Iorighef(ymin:ymax,position1(1):position2(1));
        close(ef)
        
        handles.Manualedit.Any_right = 1;
        handles.Manualedit.Tweak_right = 1;
end
   


% --- Executes on button press in Button_save.
function Button_save_Callback(hObject, eventdata, handles)
% hObject    handle to Button_save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
save_data(handles);


function save_data(handles)
data.loadfolder = handles.loadfolder;
data.dcminfo = handles.dcminfo;
data.Manualedit = handles.Manualedit;
data.rightIc = handles.rightIc;
data.leftIc = handles.leftIc;
data.right_JS_loc = handles.right_JS_loc;
data.left_JS_loc = handles.left_JS_loc;
data.right_JSdimensions = handles.right_JSdimensions;
data.left_JSdimensions = handles.left_JSdimensions;
data.right_tibia_angle = handles.right_tibia_angle;
data.left_tibia_angle = handles.left_tibia_angle;
data.right_FTANGLE = handles.right_FTANGLE;
data.left_FTANGLE = handles.left_FTANGLE;
data.right_DIMS = handles.right_DIMS;
data.left_DIMS = handles.left_DIMS;
data.right_shaftcoords = handles.right_shaftcoords;
data.left_shaftcoords = handles.left_shaftcoords;


data.Pat_ID = get(handles.Pat_ID,'String');
data.Pat_age = str2double(get(handles.Pat_age,'String'));
data.Pat_weight = str2double(get(handles.Pat_weight,'String'));
data.Pat_height = str2double(get(handles.Pat_height,'String'));
if get(handles.Pat_male,'Value')
    data.Pat_male = 1;
    data.Pat_female = 0;
elseif get(handles.Pat_female,'Value')
    data.Pat_female = 1;
    data.Pat_male = 0;
end

save([handles.savepath data.Pat_ID '.mat'],'data');

%create a new figure
newFig = figure('visible','off');

%get the units and position of the axes object
axes_units = get(handles.Main_axes,'Units');
axes_pos = get(handles.Main_axes,'Position');

%copies axesObject onto new figure
axesObject2 = copyobj(handles.Main_axes,newFig);

%realign the axes object on the new figure
set(axesObject2,'Units',axes_units);
set(axesObject2,'Position',[15 5 axes_pos(3) axes_pos(4)]);

%adjusts the new figure accordingly
set(newFig,'Units',axes_units);
set(newFig,'Position',[15 5 axes_pos(3)+30 axes_pos(4)+10]);
colormap(gray)

%saves the plot
saveas(newFig,[handles.savepath data.Pat_ID '.png'])

%closes the figure
close(newFig)

% --- Executes on button press in Button_batch.
function Button_batch_Callback(hObject, eventdata, handles)
% hObject    handle to Button_batch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isfield(handles, 'loadfolder')
    folder = uigetdir(handles.loadfolder, 'Select a folder with data-folders');    
else
    folder = uigetdir(pwd, 'Select a folder with data-folders');
end
dataf = dir(folder);
dataf(1:2) = [];

for ii = 114:length(dataf)
    if isfield(handles,'right_FTANGLE')
        rmf = {'right_FTANGLE', 'left_FTANGLE', 'right_shaftcoords', 'left_shaftcoords', 'left_DIMS', 'right_DIMS', 'Manualedit', 'rightI', 'leftI', 'rightIc', 'leftIc', 'right_JS_loc', 'left_JS_loc', 'right_JSdimensions', 'left_JSdimensions', 'right_tibia_angle', 'left_tibia_angle'};
        handles = rmfield(handles, rmf);
    end
    samplef = dataf(ii).name;    
    handles.loadfolder = [folder '\' samplef '\'];
    
    handles = load_data(handles);
    load_patient_data(handles);
    handles = automatic_analysis(handles);
    
    update_axes(handles);
    
    save_data(handles)
end


handles.loadfolder = folder;

handles = load_data(handles);

load_patient_data(handles)
handles = automatic_analysis(handles);

guidata(hObject, handles);

update_contrast(handles);
update_axes(handles);


% --- Executes on button press in Button_loaddata.
function Button_loaddata_Callback(hObject, eventdata, handles)
% hObject    handle to Button_loaddata (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'right_FTANGLE')
    rmf = {'right_FTANGLE', 'left_FTANGLE', 'right_shaftcoords', 'left_shaftcoords', 'left_DIMS', 'right_DIMS', 'Manualedit', 'rightI', 'leftI', 'rightIc', 'leftIc', 'right_JS_loc', 'left_JS_loc', 'right_JSdimensions', 'left_JSdimensions', 'right_tibia_angle', 'left_tibia_angle'};
    handles = rmfield(handles, rmf);
end
if isfield(handles, 'dataloadfolder')
    [filename,folder] = uigetfile({'*.mat', 'All Files (*.*)'}, 'Select a Data file',handles.dataloadfolder);    
else
    [filename,folder] = uigetfile({'*.mat', 'All Files (*.*)'}, 'Select a Data file');
end
handles.dataloadfolder = folder;


load([folder filename]);

set(handles.Pat_ID,'String',data.Pat_ID);
set(handles.Pat_age,'String',num2str(data.Pat_age));
set(handles.Pat_weight,'String',num2str(data.Pat_weight));
set(handles.Pat_height,'String',num2str(data.Pat_height));
if data.Pat_male
    set(handles.Pat_male,'Value',1);
elseif data.Pat_female
    set(handles.Pat_female,'Value',1);
end

if get(handles.Box_presetdir,'Value')
    handles.loadfolder = get(handles.Text_presetdir,'String');
    if ~strcmp(handles.loadfolder(end),'\')
        handles.loadfolder = [handles.loadfolder '\'];
    end
    handles.loadfolder = [handles.loadfolder data.Pat_ID '\'];
else
    handles.loadfolder = data.loadfolder;
end

handles = load_data(handles);

handles.Manualedit = data.Manualedit;
handles.rightIc = data.rightIc;
handles.leftIc = data.leftIc;
handles.right_JS_loc = data.right_JS_loc;
handles.left_JS_loc = data.left_JS_loc;
handles.right_JSdimensions = data.right_JSdimensions;
handles.left_JSdimensions = data.left_JSdimensions;
handles.right_tibia_angle = data.right_tibia_angle;
handles.left_tibia_angle = data.left_tibia_angle;
handles.right_FTANGLE = data.right_FTANGLE;
handles.left_FTANGLE = data.left_FTANGLE;
handles.right_DIMS = data.right_DIMS;
handles.left_DIMS = data.left_DIMS;
handles.right_shaftcoords = data.right_shaftcoords;
handles.left_shaftcoords = data.left_shaftcoords;

handles.rightI = handles.Iorighef(handles.rightIc(2):handles.rightIc(4)+handles.rightIc(2), handles.rightIc(1):handles.rightIc(3)+handles.rightIc(1));
handles.leftI = handles.Iorighef(handles.leftIc(2):handles.leftIc(4)+handles.leftIc(2), handles.leftIc(1):handles.leftIc(3)+handles.leftIc(1));

guidata(hObject, handles);

update_contrast(handles);
update_axes(handles);



function Text_presetdir_Callback(hObject, eventdata, handles)
% hObject    handle to Text_presetdir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Text_presetdir as text
%        str2double(get(hObject,'String')) returns contents of Text_presetdir as a double


% --- Executes during object creation, after setting all properties.
function Text_presetdir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Text_presetdir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Box_presetdir.
function Box_presetdir_Callback(hObject, eventdata, handles)
% hObject    handle to Box_presetdir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Box_presetdir



function Meas_shaftangle_left_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_shaftangle_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_shaftangle_left as text
%        str2double(get(hObject,'String')) returns contents of Meas_shaftangle_left as a double


% --- Executes during object creation, after setting all properties.
function Meas_shaftangle_left_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_shaftangle_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Meas_shaftangle_right_Callback(hObject, eventdata, handles)
% hObject    handle to Meas_shaftangle_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Meas_shaftangle_right as text
%        str2double(get(hObject,'String')) returns contents of Meas_shaftangle_right as a double


% --- Executes during object creation, after setting all properties.
function Meas_shaftangle_right_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Meas_shaftangle_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Button_Shaftangle_right.
function Button_Shaftangle_right_Callback(hObject, eventdata, handles)
% hObject    handle to Button_Shaftangle_right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'Shaftangle_right');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);

% --- Executes on button press in Button_Shaftangle_left.
function Button_Shaftangle_left_Callback(hObject, eventdata, handles)
% hObject    handle to Button_Shaftangle_left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = update_measures(handles,'Shaftangle_left');
handles = automatic_analysis(handles);
update_axes(handles);
guidata(hObject, handles);
