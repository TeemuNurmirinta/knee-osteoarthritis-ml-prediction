function tibia_angle = find_tibiaangle(I,JS_loc,TibiaROI,MinWidth,side,ftanglesmooth,addc,JS1coord,JS2coord)
% padding = MinWidth*2;
%side 1 = left, 2 = right
try
%tibia
tibplat = max([JS1coord(2,:) JS2coord(2,:)]);
bs = tibplat+TibiaROI(1);
be = tibplat+TibiaROI(2);

Icmax = max(I(:));
I = histeq(I./Icmax)*Icmax;
% 
% figure(1111)
% imagesc(I)
% axis image
% colormap(gray)
% hold on

% go through the first 10 rows at top
ri = bs;
for ii=1:10
    prof = smooth(I(ri,:),ftanglesmooth,'sgolay');
    ri = ri+1;
    fe = find(prof>mean(prof),1,'first');
    le = find(prof>mean(prof),1,'last');
    tedgelocs(ii,:) = [fe le];
%     plot(edgelocs(ii,:),[ri ri],'go')
%     pause
end
topmeanedgelocs = mean(tedgelocs,1);
topcenterloc = mean(topmeanedgelocs);

% plot(meanedgelocs,[bs bs],'ro')
% plot(topcenterloc,bs,'bo')
% hold off

% go through the last ten rows before 10 cm mark
ri = be-9;
for ii=1:10
    prof = smooth(I(ri,:),ftanglesmooth,'sgolay');
    ri = ri+1;
    prof(prof<mean(prof)) = nan;
    
    [PKS, LOCS] = findpeaks(prof,'NPeaks',3,'SortStr','descend','MinPeakDistance',MinWidth,'MinPeakProminence',10);
    
    
    if side==2 && length(LOCS) >=2
        prof(1:LOCS(1)-ftanglesmooth) = nan;
        PKS(LOCS<LOCS(1)) = []; 
        LOCS(LOCS<LOCS(1)) = [];
    elseif side==1 && length(LOCS) >=2
        prof(LOCS(1)+ftanglesmooth:end) = nan;
        PKS(LOCS>LOCS(1)) = []; 
        LOCS(LOCS>LOCS(1)) = [];   
    end
%     figure(9898)
%     plot(prof)
%     hold on
%     plot(LOCS,PKS,'ro')
%     hold off
%     pause
    if length(LOCS) == 2        
        tmp = [LOCS,PKS];
        tmp = sortrows(tmp,1);
        LOCS = tmp(:,1);
        PKS = tmp(:,2);    
        
        fe = find(prof>nanmean(prof),1,'first');
        le = find(prof>nanmean(prof),1,'last');
        bedgelocs(ii,:) = [fe le];
        
%                 figure(1111)
%                 plot(prof)
%                 hold on
%             %     plot(1:length(prof),ones(1,length(prof))*usem)
%                 plot(LOCS,PKS,'go')
%                 plot(LOCS2,prof(LOCS2),'ro')
%                 hold off
%                 pause
%         plot(LOCS,ones(length(LOCS),1)*ri,'ro')
%         pause
    else
        bedgelocs(ii,:) = [nan nan];
    end
end
% hold off
bottommeanedgelocs = mean(bedgelocs,1);
bottomcenterloc = mean(bottommeanedgelocs);

tibia_angle.angle_coordinates = [topcenterloc+addc(1) bottomcenterloc+addc(1); bs be];
tibia_angle.edge_coordinates = [topmeanedgelocs+addc(1) bottommeanedgelocs+addc(1); bs bs be be];
catch
   tibia_angle.angle_coordinates = NaN;
   tibia_angle.edge_coordinates = NaN; 
    
end
% figure(1234)
% imagesc(I)
% axis image
% colormap(gray)
% hold on
% plot(topmeanedgelocs,[bs bs],'go')
% plot(topcenterloc, bs, 'ro');
% plot(bottommeanedgelocs,[be be],'go')
% plot(bottomcenterloc, be, 'ro');
% hold off

% catch
%    tibia_angle.angle_coordinates = NaN;
%    tibia_angle.edge_coordinates = NaN;
% end