function BWout = fillbone(BWin,divider)

se = strel('disk', 10);
% BWin = imerode(BWin,se);
% BWin = imdilate(BWin,se);
% BWin = imfill(BWin,'holes');
B = bwboundaries(BWin);

BB = B{1};

bbi = 1;
for ii = min(BB(:,1)):max(BB(:,1))
    ti = find(BB(:,1) == ii);
    [~, timi] = min(BB(ti,2));
    [~, tima] = max(BB(ti,2));
    BBu(bbi,:) = BB(ti(timi),:);
    BBu(bbi+1,:) = BB(ti(tima),:);
    bbi = bbi+2;
end

y = BBu(:,2);
x = BBu(:,1);
cx = mean(x);
cy = mean(y);
a = atan2(y - cy, x - cx);
[~, order] = sort(a);
x = x(order);
y = y(order);

BWin = poly2mask(y,x,size(BWin,1),size(BWin,2));
BWin = imerode(BWin,se);
BWout = imdilate(BWin,se);

BWmean = mean(BWout,2);

[~, BWmaxI] = max(BWmean);
if BWmaxI>divider
    BWout(1:BWmaxI-1,:) = zeros(BWmaxI-1,size(BWout,2));
elseif BWmaxI<divider
    BWout(BWmaxI+1:end,:) = zeros(size(BWout,1)-BWmaxI,size(BWout,2));
end

figure
imagesc(BWout)
axis image
