function I = remove_bright_borders(I)
vmean = mean(I,1);
hmean = mean(I,2);
maxtest = 0.6*max(I(:));

for ii = 1:round(length(hmean)/2)
    if hmean(ii) >= maxtest
        I(ii,:) = 0;
    else
        break;
    end
end

for ii = fliplr(round(length(hmean)/2):length(hmean))
    if hmean(ii) >= maxtest
        I(ii,:) = 0;
    else
        break;
    end
end

for ii = 1:round(length(vmean)/2)
    if vmean(ii) >= maxtest
        I(:,ii) = 0;
    else
        break;
    end
end
for ii = fliplr(round(length(vmean)/2):length(vmean))
    if vmean(ii) >= maxtest
        I(:,ii) = 0;
    else
        break;
    end
end

end