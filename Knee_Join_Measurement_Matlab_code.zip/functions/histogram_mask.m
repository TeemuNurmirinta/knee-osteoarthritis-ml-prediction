function [mask, maskhistdata] = histogram_mask(I,masklow,usemin,saveplots,savepath,filename,hardTH,usehard)
% Find the low treshold using a histogram and create a mask using the
% determined threshold
%
% Works at least with total integration.
TH = 0;
HTH = false;
mask = ones(size(I));
[values,edges] = histcounts(I(:),200);
bincenters = (edges(1:end-1) + edges(2:end))/2;
values = movmean(values,5);
vd = diff(values);
vd = [0 vd];
ff = figure('units','normalized','outerposition',[0 0 1 1]);
subplot(121)
bar(bincenters,values)
hold on

[pks,locs] = findpeaks(values,'MinPeakDistance',5,'MinPeakHeight',100,'MinPeakProminence',50);

if masklow
    [~,sorder] = sort(locs,'descend');
else
    [~,sorder] = sort(locs,'ascend');
end
for bb = 1:length(locs)
    if bincenters(locs(end)) > 2500
        locs(end) = [];
        pks(end) = [];
    else
        break;
    end
end
        
if ~isempty(locs)
    if length(locs) > 1
        sorder = sort(sorder(1:2));
        locss = [locs(sorder(1)),locs(sorder(2))];
    else
        locss = [1, locs(sorder(1))];
    end
    if usemin
        [~, minl] = min(values(locss(1):locss(2)));
    else        
        minl = find(vd(locss(1)+1:locss(2)) > 0,1);      
    end
    minl = minl+locss(1)-1;

% if bincenters(minl) < hardTH
%     [~,minl] = min(abs(bincenters-1));
% end

TH = bincenters(minl)
end

if ~usehard
    if length(locs) <= 1 && TH < hardTH
        TH = hardTH;
        [~,minl] = min(abs(bincenters-TH));
        HTH = true;
    end
else
    TH = hardTH;
    [~,minl] = min(abs(bincenters-TH));
    HTH = true;
end

if masklow
    mask(I < TH) = 0;
else
    mask(I > TH) = 0;
end

plot(bincenters(locs),pks,'go')
plot(bincenters(minl),values(minl),'ro','MarkerSize',10,'LineWidth',2)
if HTH
    message = sprintf('HARD Threshold:\n%0.5g', TH);
else
    message = sprintf('Threshold:\n%0.5g', bincenters(minl));
end
text(bincenters(minl),max(values)/2,message,'HorizontalAlignment','center')
hold off
title('Total integration histogram indicating threshold')
subplot(122)
colormap(jet)
imagesc(I)
axis image
title('Non-masked map');
if saveplots==1
    saveas(ff,[savepath filename '_TH_histogram.png'])
%     close(ff);
end
maskhistdata.locs = locs;
maskhistdata.pks = pks;
maskhistdata.minl = minl;
maskhistdata.TH = TH;
maskhistdata.bincenters = bincenters;
maskhistdata.values = values;
maskhistdata.hardthresholdused = HTH;
maskhistdata.I = I;