function [rfbw, rtbw] = find_femur_tibia(inputIm,divider)

rbw = zeros(size(inputIm));
rfbw = rbw;
rtbw = rbw;

rbw(~isnan(inputIm)) = 1;
se = strel('disk',5);
rbw = imerode(rbw,se);
rbw = imdilate(rbw,se);
rbw = bwmorph(rbw,'clean');


fbw = rbw;
fbw(divider+1:end,:) = zeros(size(fbw,1)-divider,size(fbw,2));

tbw = rbw;
tbw(1:divider,:) = zeros(divider,size(tbw,2));


CC1 = bwconncomp(fbw);
numPixels = cellfun(@numel,CC1.PixelIdxList);
[~,IndM1] = max(numPixels);

CC2 = bwconncomp(tbw);
numPixels = cellfun(@numel,CC2.PixelIdxList);
[~,IndM2] = max(numPixels);

rfbw(CC1.PixelIdxList{IndM1}) = 1;
rtbw(CC2.PixelIdxList{IndM2}) = 1;
