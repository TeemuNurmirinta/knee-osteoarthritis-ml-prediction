function [FTANGLE, DIMS] = calculate_ftangle(JS1coord,JS2coord,cropimhc,tibia_coord,CWcoord,shaft_coord,side,pixelsize)

try
    tibia_angle = atand((tibia_coord(1,1)-tibia_coord(1,2))/(tibia_coord(2,1)-tibia_coord(2,2)));

    JScp = [JS1coord(1,1) JS2coord(1,2); JS1coord(2,1) JS2coord(2,1)];
    femur_angle = atand((JScp(2,1)-JScp(2,2))/(JScp(1,1)-JScp(1,2)));
    plotfemur_angle = femur_angle;
    if side == 2
        tibia_angle = -tibia_angle;
        femur_angle = -femur_angle;
    end
    FTANGLE.tibiaangle = tibia_angle;
    FTANGLE.femurangle = femur_angle;
    FTANGLE.ftangle = tibia_angle+femur_angle;
    
    if side == 1
        DIMS.MedJSwidth = abs(JS1coord(2,1)-JS1coord(2,2)).*pixelsize;
        DIMS.LatJSwidth = abs(JS2coord(2,1)-JS2coord(2,2)).*pixelsize;
    else    
        DIMS.LatJSwidth = abs(JS1coord(2,1)-JS1coord(2,2)).*pixelsize;
        DIMS.MedJSwidth = abs(JS2coord(2,1)-JS2coord(2,2)).*pixelsize;
    end
    DIMS.CondDist = abs(JS1coord(1,1)-JS2coord(1,1)).*pixelsize;
catch
    FTANGLE.tibiaangle = NaN;
    FTANGLE.femurangle = NaN;
    FTANGLE.ftangle = NaN;
    DIMS.LatJSwidth = NaN;
    DIMS.MedJSwidth = NaN;
    DIMS.CondDist = NaN;
end


try
    %%%%%horizontal line
    fang = polyfit(JScp(1,:), JScp(2,:),1);

    if ~isnan(cropimhc)
        JScoordx = cropimhc;
    elseif ~isnan(JS1coord)
        JScoordx = [JS1coord(1) JS2coord(1)];
    end

    JScoordy = fang(1)*JScoordx+fang(2);
    angy1 = mean(JScoordy); %OK

    JScoord = [JScoordx;JScoordy];
    FTANGLE.JScoord = JScoord;
catch
    FTANGLE.JScoord = NaN;
end

try
    %length of lines
    anglen = abs(diff(tibia_coord(2,:)))*1.25;

    %%%%%femur vertical line
    angx1 = CWcoord(1,2);%mean(JScp(1,:)); %OK    

    angy2 = anglen*sind(plotfemur_angle-90)+angy1;
    angx2 = anglen*cosd(plotfemur_angle-90)+angx1;
    JScoord90 = [angx1 angx2; angy1 angy2];
    
    FTANGLE.JScoord90 = JScoord90;
    DIMS.CWwidth = abs(diff(CWcoord(1,:))).*pixelsize;
    DIMS.CWwidth(3) = sum(DIMS.CWwidth);
catch
    FTANGLE.JScoord90 = NaN;
    DIMS.CWwidth = NaN;
    DIMS.CWwidth(3) = NaN;
end

try
    %%%%%tibia vertical line
    tang = polyfit(tibia_coord(2,:), tibia_coord(1,:),1);

    Tcoordy = [angy1 tibia_coord(2,2)*1.1];
    Tcoordx = tang(1)*Tcoordy+tang(2);

    tibia_coord = [Tcoordx;Tcoordy];
    FTANGLE.tibia_coord = tibia_coord;
catch
    FTANGLE.tibia_coord = NaN;
end

try
    sfemur_angle = atand((shaft_coord.femur_coords(1,2)-shaft_coord.femur_coords(1,1))/(shaft_coord.femur_coords(2,2)-shaft_coord.femur_coords(2,1)));
    stibia_angle = atand((shaft_coord.tibia_coords(1,2)-shaft_coord.tibia_coords(1,1))/(shaft_coord.tibia_coords(2,2)-shaft_coord.tibia_coords(2,1)));
    if side == 1
        sfemur_angle = -sfemur_angle;
    elseif side == 2
        stibia_angle = -stibia_angle;
    end

    shaft_angle = sfemur_angle+stibia_angle;
    FTANGLE.shaft_angle = shaft_angle;
    FTANGLE.shaft_femur_angle = sfemur_angle;
    FTANGLE.shaft_tibia_angle = stibia_angle;
catch
    FTANGLE.shaft_angle = NaN;
    FTANGLE.shaft_femur_angle = NaN;
    FTANGLE.shaft_tibia_angle = NaN;
end
    