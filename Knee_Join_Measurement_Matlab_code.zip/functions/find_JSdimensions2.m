function JSdimensions = find_JSdimensions2(I,JS_locm,JSmargin,MinWidth,side,smoothing,locTH,pixelsize,addc)

% figure(1313)
% imagesc(I)
% axis image
try
Icroptop = round(JS_locm-JSmargin);
Icropbottom = round(JS_locm+JSmargin);

Ic = I(Icroptop:Icropbottom,:);

% equalize the histogram for cropped
Icmax = max(Ic(:));
Ic = histeq(Ic./Icmax)*Icmax;

% average horizontal intensity vector
Ichv = mean(Ic,1);

% crop the vector in horizontal direction
Is = find(Ichv(1:round(length(Ichv)/2))>mean(Ichv)/2,1,'first');
Ie = find(Ichv(round(length(Ichv)/2:end))>mean(Ichv)/2,1,'last')+round(length(Ichv)/2)-1;
Ic = Ic(:,Is:Ie);

% find the complete jointspace
[JSx, JSy, quantn] = defineJS(Ic,locTH,smoothing);
% quantn
% size(JSx)
% size(JSy)
% interpolate the jointspace "curve" for every pixel
JSxi = JSx(1):1:JSx(end);
JSys = interp1(JSx,JSy,JSxi);
JSys = smooth(JSys,smoothing*4,'sgolay');

%find minimum (CW point)
%only check the 70% of the middle of the curve
JSyss = round(0.15*length(JSys));
JSyse = round(0.85*length(JSys));
JSyst = JSys;
JSyst(1:JSyss) = nan(1,JSyss);
JSyst(JSyse:end) = nan(1,length(JSys)-JSyse+1);

[~, CWi] = min(JSyst);
[~, CWio] = min(abs(JSx-JSxi(CWi)));

%find maxima on both side (JS points)
[~, JSi1] = max(JSys(1:CWi-1));
[~, JSi2] = max(JSys((CWi):end));
[~, JSi1o] = max(JSy(1:CWio-1));
[~, JSi2o] = max(JSy((CWio):end));
JSi2 = JSi2+CWi-1;
JSi2o = JSi2o+CWio-1;

JS1iLoc = JSxi(JSi1);
JS2iLoc = JSxi(JSi2);
JS1oLoc = JSx(JSi1o);
JS2oLoc = JSx(JSi2o);
CWLoc = JSxi(CWi);

JS1Loc = max(JS1iLoc, JS1oLoc)+round(0.02*size(Ic,2));
JS2Loc = min(JS2iLoc, JS2oLoc)-round(0.02*size(Ic,2));

% the JS and CW profiles
JS1prof = smooth(Ic(:,JS1Loc),smoothing,'sgolay');
JS2prof = smooth(Ic(:,JS2Loc),smoothing,'sgolay');
CWprof = smooth(Ic(:,CWLoc),smoothing,'sgolay');


% define the JS widths
[PKS,LOCS] = findpeaks(JS1prof,'MinPeakHeight',mean(JS1prof));

JS1s = find(LOCS<JSys(JSxi == JS1Loc),1,'last');
JS1e = find(LOCS>JSys(JSxi == JS1Loc),1,'first');

JS1PKS = PKS([JS1s JS1e]);
JS1LOCS = LOCS([JS1s JS1e]);

[PKS,LOCS] = findpeaks(JS2prof,'MinPeakHeight',mean(JS2prof));

JS2s = find(LOCS<JSys(JSxi == JS2Loc),1,'last');
JS2e = find(LOCS>JSys(JSxi == JS2Loc),1,'first');

JS2PKS = PKS([JS2s JS2e]);
JS2LOCS = LOCS([JS2s JS2e]);

Xp = 1:length(JS1prof);

if size(JS1prof,1) > size(JS1prof,2)
    JS1prof = JS1prof';
end
if size(JS2prof,1) > size(JS2prof,2)
    JS2prof = JS2prof';
end

% baseline correction of profiles for gaussian fitting
JS1prof = baseline_correction(Xp,JS1prof,JS1LOCS);
JS2prof = baseline_correction(Xp,JS2prof,JS2LOCS);

% remove other than peaks
JS1prof(1:JS1LOCS(1)) = zeros(1,JS1LOCS(1));
JS1prof(JS1LOCS(2):end) = zeros(1,length(JS1prof)-JS1LOCS(2)+1);

JS2prof(1:JS2LOCS(1)) = zeros(1,JS2LOCS(1));
JS2prof(JS2LOCS(2):end) = zeros(1,length(JS2prof)-JS2LOCS(2)+1);

% fit gaussian
[sigma1,mu1,A1]=mygaussfit(Xp,-JS1prof);
% gf1=A1*exp(-(Xp-mu1).^2/(2*sigma1^2)); %gaussian curve

[sigma2,mu2,A2]=mygaussfit(Xp,-JS2prof);
% gf2=A2*exp(-(Xp-mu2).^2/(2*sigma2^2)); %gaussian curve

%FWHM of the gaussian curve/2
gfdev1 = 2.35482*sigma1/2;
gfdev2 = 2.35482*sigma2/2;

% define the CW widths
[PKS,LOCS] = findpeaks(CWprof,'MinPeakHeight',mean(CWprof));

CWs = find(LOCS<JSys(JSxi == CWLoc),1,'last');
CWe = find(LOCS>JSys(JSxi == CWLoc),1,'first');

CWPKS = PKS([CWs CWe]);
CWLOCS = LOCS([CWs CWe]);

if size(CWprof,1) > size(CWprof,2)
    CWprof = CWprof';
end

% baseline correction of profiles for gaussian fitting
CWprof = baseline_correction(Xp,CWprof,CWLOCS);
CWprof = baseline_correction(Xp,CWprof,CWLOCS);

% remove other than peaks
CWprof(1:CWLOCS(1)) = zeros(1,CWLOCS(1));
CWprof(CWLOCS(2):end) = zeros(1,length(CWprof)-CWLOCS(2)+1);

% fit gaussian
[sigma3,mu3,A3]=mygaussfit(Xp,-CWprof);
% gf3=A3*exp(-(Xp-mu3).^2/(2*sigma3^2)); %gaussian curve

gfdev3 = 2.35482*sigma3/2;%FWHM of the gaussian curve/2
CWlocm = round(mu3-gfdev3);
    

% CWprofH = smooth(Ic(CWlocm,:).^2,smoothing/2,'sgolay');
pad = round(MinWidth/2);
CWprofH = mean(Ic(CWlocm-pad:CWlocm+pad,:),1).^2;

% if side == 1
%     CWprofH = fliplr(CWprofH);
% end
% dd = [0 diff(CWprofH,1)];
% dd(dd<0) = 0;
% dd = smooth(dd,smoothing,'sgolay');
% dd(dd<0) = 0;
% [ddp1,ddl1] = findpeaks(dd(1:CWLoc),'MinPeakHeight',mean(abs(dd(1:CWLoc))),'MinPeakDistance',smoothing/4);
% [ddp2,ddl2] = findpeaks(dd(CWLoc:end),'MinPeakHeight',mean(abs(dd(CWLoc:end)))/2,'MinPeakDistance',smoothing/4);
[ddp1,ddl1] = findpeaks(CWprofH(1:CWLoc),'MinPeakHeight',mean(CWprofH(1:CWLoc))/2,'MinPeakDistance',smoothing/4);
[ddp2,ddl2] = findpeaks(CWprofH(CWLoc:end),'MinPeakHeight',mean(CWprofH(CWLoc:end))/2,'MinPeakDistance',smoothing/4);
% [ddp1,ddl1] = findpeaks(CWprofH(1:CWLoc),'MinPeakDistance',smoothing/4,'MinPeak%%Prominence',100000);
% [ddp2,ddl2] = findpeaks(CWprofH(CWLoc:end),'MinPeakDistance',smoothing/4,'MinPeak%%Prominence',100000);

ddl2 = ddl2+CWLoc-1;
ddp = [ddp1 ddp2];
ddl = [ddl1 ddl2];
% if side == 1
%     ddl = [ddl1-round(MinWidth*0.75) ddl2+MinWidth];
% elseif side == 2
%     ddl = [ddl1-MinWidth ddl2+round(MinWidth*0.75)];
% end

% final coordinates in the cropped image
JS1LOCSfc = [JS1Loc JS1Loc; round([mu1-gfdev1 mu1+gfdev1])];
JS2LOCSfc = [JS2Loc JS2Loc; round([mu2-gfdev2 mu2+gfdev2])];
CWLOCSfc = [ddl(1) CWLoc ddl(end); CWlocm CWlocm CWlocm];

% "angle of JS"
% JScp = [JS1Loc JS2Loc; mean(JS1LOCSfc(2,:)) mean(JS2LOCSfc(2,:))];
% femur_angle = atand((JScp(2,1)-JScp(2,2))/(JScp(1,1)-JScp(1,2)));


% Anglinex = [1 CWlocm];
% Angliney = [CWlocm*sind(JSang)+CWLoc CWLoc];
% Angline = [Angliney; Anglinex];
% pang = polyfit(JSang(1,:), JSang(2,:),1);
% fang = polyval(pang,1:

% transform the coordinates to original image
JS1LOCSf = [JS1LOCSfc(1,:)+addc(1)+Is; JS1LOCSfc(2,:)+Icroptop];
JS2LOCSf = [JS2LOCSfc(1,:)+addc(1)+Is; JS2LOCSfc(2,:)+Icroptop];
CWLOCSf = [CWLOCSfc(1,:)+addc(1)+Is; CWLOCSfc(2,:)+Icroptop];

cropimhc = [Is Ie]+addc(1);
if side == 1
    JSdimensions.LatJScoord = JS2LOCSf;
    JSdimensions.MedJScoord = JS1LOCSf;
    JSdimensions.CWcoord = fliplr(CWLOCSf);    
elseif side == 2
    JSdimensions.LatJScoord = JS1LOCSf;
    JSdimensions.MedJScoord = JS2LOCSf;    
    JSdimensions.CWcoord = CWLOCSf;
end
JSdimensions.Cropimhc = cropimhc;  
catch
    JSdimensions.LatJScoord = NaN;
    JSdimensions.MedJScoord = NaN;
    JSdimensions.CWcoord = NaN;    
    JSdimensions.Cropimhc = NaN;
end
% 
% figure(989)
% plot(CWprofH)
% hold on
% % plot(dd)
% plot(ddl,ddp,'ro')
% hold off

% figure(321)
% subplot(1,3,1)
% plot(-JS1prof)
% hold on
% plot(gf1)
% plot(JS1LOCSf,-JS1prof(JS1LOCSf),'ro')
% hold off
% title('JS1')
% subplot(1,3,2)
% plot(-JS2prof)
% hold on
% plot(gf2)
% plot(JS2LOCSf,-JS2prof(JS2LOCSf),'ro')
% hold off
% title('JS2')
% subplot(1,3,3)
% plot(CWprof)
% hold on
% plot(CWLOCS,CWPKS,'ro')
% hold off
% title('CW')

% figure(323)
% imagesc(Ic)
% axis image
% colormap(gray)
% hold on
% % plot(JSxi,JSys,'ro')
% line(JS1LOCSfc(1,:), JS1LOCSfc(2,:),'Color','g','LineWidth',2)
% % line(JScp(1,:), JScp(2,:),'Color','w','LineWidth',2)
% % line(Angline(1,:), Angline(2,:),'Color','w','LineWidth',2)
% % line([CWLoc CWLoc], [1 size(Ic,1)],'Color','b','LineWidth',2)
% line(JS2LOCSfc(1,:), JS2LOCSfc(2,:),'Color','r','LineWidth',2)
% line(CWLOCSfc(1,1:2), CWLOCSfc(2,1:2),'Color','g','LineWidth',2);
% line(CWLOCSfc(1,2:3), CWLOCSfc(2,2:3),'Color','r','LineWidth',2);
% plot(CWLOCSfc(1,2), CWLOCSfc(2,2),  'ko')
% hold off


