function data=remove_outlier(data)
% Removes spectra, assigned to the outliers from the data matrix using
% 3-sigma rule

    % Calculates the mean and the standard deviation
    mu = nanmean(data(:));
    sigma = nanstd(data(:));
    
    outliers = abs(data-mu) > 3*sigma;
    data(outliers==1) = NaN;    
end