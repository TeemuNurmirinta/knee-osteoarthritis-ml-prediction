function JSdimensions = find_JSdimensions(I,JS_locm,JSmargin,MinWidth,side,smoothing,locTH)

Ic = I(JS_locm-JSmargin/3:JS_locm+JSmargin/3,:);
% Ic = medfilt2(Ic,[locTH locTH]);
% imean = mean(Ic,1);
% [~,Istart] = find(imean>median(imean)/1.5,1);
% [~,Iend] = find(imean>median(imean)/1.5,1,'last');
% figure(4321)
% plot(imean)

Xl = 1:size(Ic,1);
% figure(1235)
% imagesc(Ic)
% colormap(gray)
% axis image
npoints = size(Ic,2);
ccx = 1;
for ii = 1:npoints
    prof = smooth(Ic(:,ii),smoothing,'sgolay');
    TFl = islocalmin(prof,'MinProminence',200,'ProminenceWindow',100);
    lJSl = round(prof(TFl));
    loc = Xl(TFl);
    if length(loc) > 1
        [minV,mini] = min(lJSl);
        loc = loc(mini);
    end
    
    if ~isempty(loc)
        JS_locX(ccx,:) = [ii,loc];
%         plot(prof)
%         hold on
%         plot(loc,lJSl,'ro')
%         plot(ones(length(loc),1)*ii,loc,'ro')
%         hold off
%         pause
        ccx=ccx+1;
    end
    
    
end
JS_locX(:,2) = remove_outlier(JS_locX(:,2));
JS_locX(:,2) = smooth(JS_locX(:,2),smoothing/2,'sgolay');

I = find(JS_locX(:,2)<median(JS_locX(1:MinWidth*2,2))-locTH,1);
JS_locXf = flipud(JS_locX);
I2 = find(JS_locXf(:,2)<median(JS_locXf(1:MinWidth*2,2))-locTH,1);
I2 = length(JS_locX)-I2;
% if side == 1
%     figure(1234)    
% elseif side == 2
%     figure(1235)
% end
% plot(JS_locX(:,1), JS_locX(:,2))
% hold on
% plot(JS_locX(I,1),JS_locX(I,2),'ro')
% plot(JS_locX(I2,1),JS_locX(I2,2),'ro')
% hold off


%  %find concecutive peaks based on derivative
% JS_locdiffX = abs(diff(JS_locX(:,1)))<=locTH;
% JS_locdiffY = abs(diff(JS_locX(:,2)))<=locTH;
% 
% % showthis = [contactx,[0;contactxdiff],[0;contactxdiffY]]
% 
% %merge the above
% contacttest = JS_locdiffX.*JS_locdiffY;
% 
% %find the number of consecutive found peaks
% out     = zeros(size(contacttest'));
% aa      = [0,contacttest',0];
% ii      = strfind(aa, [0 1]);
% out(ii) = strfind(aa, [1 0]) - ii;
% 
% %find the 2 largest regions
% [Mmaxt(:),Imaxt(:)] = maxk(out,2);
% 
% Mmax = Mmaxt(:);
% Imax = Imaxt(:);
% 
midcontact1 = round(JS_locX(1,1)+(JS_locX(I,1)-JS_locX(1,1))/2);
midcontact2 = round(JS_locX(I2,1)+(JS_locX(end,1)-JS_locX(I2,1))/2);
% 
% %plot the contacts (comment out!)
if side == 1
    figure(212)
elseif side == 2
    figure(213)
end
imagesc(Ic)
colormap(gray)
hold on
axis image
scatter(JS_locX(:,1),JS_locX(:,2),40,[0 0 1])
scatter(JS_locX(1:I,1),JS_locX(1:I,2),40,[1 0 0])
scatter(JS_locX(I2:end,1),JS_locX(I2:end,2),40,[1 1 0])
plot(ones(size(Ic,1),1)*midcontact1,1:size(Ic,1))
plot(ones(size(Ic,1),1)*midcontact2,1:size(Ic,1))
hold off


% if side==1
%     JS_loc_lat = JS_loc(round(npoints/2):end);
%     JS_loc_med = JS_loc(1:round(npoints/2)-1);
% elseif side==2
%     JS_loc_lat = JS_loc(1:round(npoints/2)-1);
%     JS_loc_med = JS_loc(round(npoints/2):end);
% end

% M��RIT� MY�S AP "LEVEYS" (yhteens� AP leveydet = femur leveys)

% JS_loc_lat = remove_outlier(JS_loc_lat);
% JS_loc_lat(abs(JS_loc_lat-nanmedian(JS_loc_lat))>locTH) = NaN;
% 
% JS_loc_med = remove_outlier(JS_loc_med);
% JS_loc_med(abs(JS_loc_med-nanmedian(JS_loc_med))>locTH) = NaN;
% if side==1
%     figure(1231)
%     imagesc(Ic)
%     colormap(gray)
%     axis image
%     hold on
%     plot(round(npoints/2):npoints,JS_loc_lat,'ro')
%     plot(1:round(npoints/2)-1,JS_loc_med,'go')
%     hold off
% elseif side==2
%     figure(1232)
%     imagesc(Ic)
%     colormap(gray)
%     axis image
%     hold on
%     plot(1:round(npoints/2)-1,JS_loc_lat,'ro')
%     plot(round(npoints/2):npoints,JS_loc_med,'go')
%     hold off
% end

JSdimensions.LatJS = 1;
JSdimensions.MedJS = 1;
JSdimensions.CondDist = 1;