function [rightI, leftI, rightIc, leftIc] = find_left_right(I,addside,sidesmooth)

try
q = quantile(I(:),5);
mask = imbinarize(I,q(3));
Ic = I.*mask;

%     figure(5656)
%     imshowpair(I,Ic,'montage')
Ifav = Ic;
Ifav(Ifav==max(Ifav(:))) = 0;
Iav = smooth(mean(Ifav),sidesmooth,'sgolay');
% Iav = Iav(round(addside/2):end-round(addside/2));
rightIv = [1, size(Ic,1)];
leftIv = [1, size(Ic,1)];
% figure(667)
% plot(Iav)
% hold on

[PKS,LOCS] = findpeaks(Iav,'NPeaks',2,'MinPeakDistance',length(Iav)/4,'MinPeakProminence',max(Iav)/3,'MinPeakHeight',max(Iav)*(2/3),'MinPeakWidth',addside);
[PKS1, LOCS1] = findpeaks(-Iav,'MinPeakHeight',min(-Iav)*(2/5));%'MinPeakDistance',length(Iav)/20,
IL = find(LOCS1<LOCS(1));
TL = LOCS1(IL);
[~,PK11I] = min(abs(LOCS(1)-TL));
PK11 = TL(PK11I);
IL = find(LOCS1>LOCS(1));
TL = LOCS1(IL);
[~,PK12I] = min(abs(LOCS(1)-TL));
PK12 = TL(PK12I);

if isempty(PK11)
    PK11 = round(addside/2);
end
if isempty(PK12)
    PK12 = round(mean(LOCS))-round(addside/2);
end

IL = find(LOCS1<LOCS(2));
TL = LOCS1(IL);
[~,PK21I] = min(abs(LOCS(2)-TL));
PK21 = TL(PK21I);
IL = find(LOCS1>LOCS(2));
TL = LOCS1(IL);
[~,PK22I] = min(abs(LOCS(2)-TL));
PK22 = TL(PK22I);

if isempty(PK21)
    PK21 = round(mean(LOCS))+round(addside/2);
end
if isempty(PK22)
    PK22 = length(Iav)-round(addside/2);
end

PK1minL = [PK11 PK12];
PK2minL = [PK21 PK22];

% plot(LOCS,PKS,'ro')
% plot(PK1minL, PK1minV,'go')
% plot(PK2minL, PK2minV,'bo')
% hold off

I1s = PK1minL(1);%-round(addside/2);%+addside;
I1e = PK1minL(2);%+round(addside/2);%-addside/4;
I2s = PK2minL(1);%-round(addside/2);%+addside/4;
I2e = PK2minL(2);%+round(addside/2);%-addside;

rightIc = [I1s, rightIv(1), I1e-I1s, rightIv(2)-rightIv(1)];
leftIc = [I2s, leftIv(1), I2e-I2s, leftIv(2)-leftIv(1)];

rightI = I(rightIv(1):rightIv(2), I1s:I1e);
leftI = I(leftIv(1):leftIv(2),I2s:I2e);


% figure
% imagesc(rightI)
% axis image
% 
% figure
% imagesc(leftI)
% axis image
catch
    rightIc = NaN;
    leftIc = NaN;

    rightI = NaN;
    leftI = NaN;
end