function Y = baseline_correction(X,Y,bl_points)
% makes a baseline correction
% spectrum can be a vector (1 spectrum) or a 2d matrix (many spectra)
% the spectra needs to be in rows (1 x N)

%if no baseline points given, do a constant baseline correction using the
%spectrum minimum
if (nargin < 3) == 1
    for ii = 1:size(Y,1)
        bl(ii) = min(Y(ii,:));
        Y(ii,:)=Y(ii,:)-bl(ii);
    end
else
    bl_points = sort(bl_points);
    
    % find the indices of the given baseline points
    for w=1:(numel(bl_points))
        [~,bl_points(w)] = min(abs(X-bl_points(w)));
    end
    % if only one baseline point given, make a constant baseline correction
    % using that point (set to zero)
    if numel(bl_points) == 1
        for ii = 1:size(Y,1)
            bl(ii) = Y(ii,bl_points);
            Y(ii,:)=Y(ii,:)-bl(ii);
        end
    else
        % Fit a polynomial to the points. Degree is number of bl_points -1
        for ii = 1:size(Y,1)
            a = polyfit(X(bl_points),Y(ii,bl_points),(numel(bl_points)-1));        
            % subtract the baseline from the spectrum
            bl = polyval(a,X);
            Y(ii,:) = Y(ii,:)-bl;
        end
    end
end
