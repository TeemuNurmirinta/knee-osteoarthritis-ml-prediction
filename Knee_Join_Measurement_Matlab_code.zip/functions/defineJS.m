function [JSx, JSy, quantn] = defineJS(Ic,locTH,finSmooth)

se = strel('sphere',locTH);
q = quantile(Ic(:),5);
mask = imbinarize(Ic,q(1));
mask = imopen(mask,se);
mask = imclose(mask,se);
mask = bwareafilt(mask,2);
Icf = Ic.*mask; 

%%%%%%%KOKEILE HISTOGRAM_MASK%%%%%%%%%%%%%
% mask = histogram_mask(Ic,0,1,0,'','',0,0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parts = 10;
partwidth = round(size(Ic,2)/parts);
partsw = [ones(1,parts-1)*partwidth size(Ic,2)-(parts-1)*partwidth];
partswc = [1 cumsum(partsw)];
doagain = 1;
quantn = 2;
while doagain
    for ii = 1:parts
        Ip = Icf(:,partswc(ii):partswc(ii+1));
        q = quantile(Ip(:),9);
        maskt = imbinarize(Ip,q(quantn));

        mask(:,partswc(ii):partswc(ii+1)) = maskt;   
    end
    mask = imopen(mask,se);
    mask = imclose(mask,se);
    mask = bwareafilt(mask,2);
    mask = imfill(mask,'holes');
    Icm = Ic.*mask; 

    %%%%%%%%%%%%%%%%%%%%%%5

%     figure(1234)
%     imshowpair(Icf,Icm,'montage')

    npoints = size(Ic,2);
    testvec = fliplr(1:size(Ic,1));
    ci = 1;
    Mmaxt = [];
    Imaxt = [];
    for ii = 1:npoints
        p = mask(:,ii);
        if sum(p)>0
            out     = zeros(size(p'));
            aa      = [1,p',1];
            in      = strfind(aa, [1 0]);
            out(in) = abs(in - strfind(aa, [0 1]));
            out(1) = 0;
            tve = find(testvec-out == 0);
            if ~isempty(tve)
                out(tve) = 0;
            end
            if sum(out)>0
                [Mmaxt(ci,:),Imaxt(ci,:)] = maxk(out,2);
                Mx(ci) = ii;
                ci = ci+1;
            end       
        end
    end
    Mmaxt(Mmaxt == 0) = NaN;
    Imaxt(Imaxt == 0) = NaN;
    Mmaxtd = [0,0;abs(diff(Mmaxt,1,1))];
    Imaxtd = [0,0;abs(diff(Imaxt,1,1))];

    Smaxtd = Mmaxtd+Imaxtd;

    jslm = zeros(length(Smaxtd),1);

    %%%% IMPORTANT TH %%%%%%
    jslm(Smaxtd(:,1) > 50) = 1;

    % remove small deviating regions and combine surroundings
    tempI = find(jslm == 1);
    meani = [];
    meani2 = [];
    if ~isempty(tempI)
        tempI = [1;tempI;length(jslm)+1];
        tempId = diff(tempI);
        for ii = 1:length(tempI)-1
            si = tempI(ii);
            ei = tempI(ii+1)-1;      
            if tempId(ii) < 5
                Mmaxt(si:ei,:) = nan(length(si:ei),2);
                Imaxt(si:ei,:) = nan(length(si:ei),2);
                meani(ii,:) = [NaN NaN];
                meani2(ii,:) = [NaN NaN];
                tempI(ii) = NaN;
            else
                meani(ii,:) = [mean(Mmaxt(si:ei,1)) mean(Imaxt(si:ei,1))];
                meani2(ii,:) = [mean(Mmaxt(si:ei,2)) mean(Imaxt(si:ei,2))];
            end          
        end
    end
    tempI(isnan(tempI)) = [];
    meani2(isnan(meani(:,1)),:) = [];
    meani(isnan(meani(:,1)),:) = [];
    tempId = diff(tempI);

    % compare remaining regions to weighted mean of all regions
    wmeani = sum(meani.*[tempId tempId])./sum(tempId);

    testm1 = abs(meani-wmeani);
    testm2 = abs(meani2-wmeani);

    % compare the 2 different options for best region (if any) and choose the
    % better one 
    Mmt = [];
    Imt = [];
    for ii = 1:size(testm1,1)
        si = tempI(ii);
        ei = tempI(ii+1)-1;
        if testm2(ii,1)+testm2(ii,2) < testm1(ii,1)+testm1(ii,2)
            Mmt(si:ei,1) = Mmaxt(si:ei,2);
            Imt(si:ei,1) = Imaxt(si:ei,2);
        else
            Mmt(si:ei,1) = Mmaxt(si:ei,1);
            Imt(si:ei,1) = Imaxt(si:ei,1);
        end
    end

    % refine the final best regions

    Mmtd = [0;abs(diff(Mmt))];
    Imtd = [0;abs(diff(Imt))];

    Smtd = Mmtd+Imtd;

    jslm2 = zeros(length(Smtd),1);

    %%%% IMPORTANT TH %%%%%%
    jslm2(Smtd > 50) = 1;

    tempI2 = find(jslm2 == 1);

    tempI2 = [1;tempI2;length(jslm2)+1];
    tempId2 = diff(tempI2);


    for ii = 1:length(tempId2)
        %%%% IMPORTANT TH %%%%%%
        if tempId2(ii) < 50
            si = tempI2(ii);
            ei = tempI2(ii+1)-1;
            Mmt(si:ei) = nan(length(si:ei),1);
            Imt(si:ei) = nan(length(si:ei),1);
        end
    end


    midl = Imt+round(Mmt/2);

    % [Mmaxt Imaxt Mmt Imt midl]

    midl = remove_outlier(midl);
    
    Mx(isnan(midl)) = [];
    midl(isnan(midl)) = [];
    
%     try
%     figure(1235)
%     imagesc(Ic)
%     axis image
%     colormap(gray)
%     hold on
%     plot(Mx,midl,'ro')
%     hold off
%     catch
%         disp('plot error')
%     end

    if length(midl) > npoints*0.5 || quantn == 6
        doagain = 0;
%         disp('all done')
    else
        quantn = quantn+1;
%         disp('do again')
    end
end

midl = smooth(midl,finSmooth,'sgolay');

JSx = Mx;
JSy = midl;