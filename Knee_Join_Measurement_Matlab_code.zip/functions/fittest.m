function [yy, Vf] = fittest(x,y,V)

options = optimset('lsqnonlin');
options.Display = 'off';

Vf = lsqnonlin(@step_fit,V,[0 0 0 0 0],[length(x) length(x) inf inf inf],options);

    % Optimizing function
    function f=step_fit(V) 
    % PIECEWISELINE   A line made of two pieces
    % that is not continuous.
    a = V(1);
    b = V(2);
    c = V(3);
    d = V(4);
    e = V(5);

    yy = zeros(length(x));

%     for ilx = 1:100
       yy(1:a-1) = c;
       yy(a:b) = d;
       yy(b+1:end) = e;            
%     end

    f = abs(y-yy);
    end
end