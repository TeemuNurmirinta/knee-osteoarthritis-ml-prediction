function FTANGLE = find_shaft_angle(I,JS_loc,JSmargin,MinWidth,side,ftanglesmooth,locTH,addc)
padding = MinWidth*2;
%side 1 = left, 2 = right
try
%femur
bs = padding;
be = JS_loc-JSmargin;
midlocf = zeros(1,be-bs+1);

ri = bs;
for ii=1:be-bs+1
    prof = smooth(I(ri,:),ftanglesmooth,'sgolay');    
    ri = ri+1;
    [PKS, LOCS] = findpeaks(prof,'NPeaks',3,'SortStr','descend','MinPeakDistance',MinWidth,'MinPeakProminence',10);
    
    if length(LOCS) == 3
        [~,LOCI] = min(PKS);
        LOCS(LOCI) = [];
        PKS(LOCI) = [];
    end
    
     if length(LOCS) == 2        
        tmp = [LOCS,PKS];
        tmp = sortrows(tmp,1);
        LOCS = tmp(:,1);
        PKS = tmp(:,2);  
        
        prof(1:LOCS(1)-50) = nan(LOCS(1)-50,1);
        prof(LOCS(2)+50:end) = nan(length(prof)-LOCS(2)-50+1,1);
        usem = min(prof(LOCS(1):LOCS(2)))-10;

        LOCS2(1) = find(prof>usem,1);
        LOCS2(2) = find(prof>usem,1,'last');
        midlocf(ii) = round((LOCS2(1)+LOCS2(2))/2);
%                 figure(1111)
%                 plot(prof)
%                 hold on
%             %     plot(1:length(prof),ones(1,length(prof))*usem)
%                 plot(LOCS,PKS,'go')
%                 plot(LOCS2,prof(LOCS2),'ro')
%                 hold off
%                 pause
    else
        midlocf(ii) = nan;
    end
end
Xf = bs:be;

middataf = [midlocf',Xf'];

middataf(isnan(midlocf'),:) = [];

P = polyfit(middataf(:,2),middataf(:,1),1);
centerline = polyval(P,middataf(:,2));

error = abs(centerline-middataf(:,1));
meaner = 2*mean(error);

middataf(error>meaner,:) = [];

femur_P = polyfit(middataf(:,2),middataf(:,1),1);
femur_centerline = polyval(femur_P,1:JS_loc);
femur_X = 1:JS_loc;

% femur_angle = atand((femur_centerline(end)-femur_centerline(1))/(femur_X(end)-femur_X(1)));

%tibia
bs = JS_loc+JSmargin;
be = size(I,1)-padding;

midloct = zeros(1,be-bs+1);

ri = bs;
for ii=1:be-bs+1
    prof = smooth(I(ri,:),ftanglesmooth,'sgolay');
    ri = ri+1;
    prof(prof<mean(prof)) = nan;
    [PKS, LOCS] = findpeaks(prof,'NPeaks',3,'SortStr','descend','MinPeakDistance',MinWidth,'MinPeakProminence',10);   
        if side==2 && length(LOCS) >=2           
            PKS(LOCS<LOCS(1)) = []; 
            LOCS(LOCS<LOCS(1)) = [];
        elseif side==1 && length(LOCS) >=2
            PKS(LOCS>LOCS(1)) = []; 
            LOCS(LOCS>LOCS(1)) = [];   
        end
    if length(LOCS) == 2        
        tmp = [LOCS,PKS];
        tmp = sortrows(tmp,1);
        LOCS = tmp(:,1);
        PKS = tmp(:,2);    
        
        prof(1:LOCS(1)-50) = nan(LOCS(1)-50,1);
        prof(LOCS(2)+50:end) = nan(length(prof)-LOCS(2)-50+1,1);
        usem = min(prof(LOCS(1):LOCS(2)))-10;

        LOCS2(1) = find(prof>usem,1);
        LOCS2(2) = find(prof>usem,1,'last');
        midloct(ii) = round((LOCS2(1)+LOCS2(2))/2);
%                 figure(1111)
%                 plot(prof)
%                 hold on
%             %     plot(1:length(prof),ones(1,length(prof))*usem)
%                 plot(LOCS,PKS,'go')
%                 plot(LOCS2,prof(LOCS2),'ro')
%                 hold off
%                 pause
    else
        midloct(ii) = nan;
    end
end
Xt = bs:be;

middatat = [midloct',Xt'];

middatat(isnan(midloct'),:) = [];

P = polyfit(middatat(:,2),middatat(:,1),1);
centerline = polyval(P,middatat(:,2));

error = abs(centerline-middatat(:,1));
meaner = 2*mean(error);

middatat(error>meaner,:) = [];

tibia_P = polyfit(middatat(:,2),middatat(:,1),1);
tibia_centerline = polyval(tibia_P,JS_loc:size(I,1));
tibia_X = JS_loc:size(I,1);

% tibia_angle = atand((tibia_centerline(end)-tibia_centerline(1))/(tibia_X(end)-tibia_X(1)));


% if side == 1
%     femur_angle = -femur_angle;
% elseif side == 2
%     tibia_angle = -tibia_angle;
% end
% 
% shaft_angle = femur_angle+tibia_angle;

% FTANGLE.shaft_angle = shaft_angle;
% FTANGLE.femur_angle = femur_angle;
% FTANGLE.tibia_angle = tibia_angle;
FTANGLE.femur_coords = [[femur_centerline(1) femur_centerline(end)]+addc(1); [femur_X(1) femur_X(end)]];
FTANGLE.tibia_coords = [[tibia_centerline(1) tibia_centerline(end)]+addc(1); [tibia_X(1) tibia_X(end)]];
catch
%     FTANGLE.shaft_angle = nan;
%     FTANGLE.femur_angle = nan;
%     FTANGLE.tibia_angle = nan;
    FTANGLE.femur_coords = nan;
    FTANGLE.tibia_coords = nan;
end