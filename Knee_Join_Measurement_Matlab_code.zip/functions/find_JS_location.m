function JS_loc = find_JS_location(I,locTH,MinWidth)

%%%%%%%%%%%%%% LIS�� TESTI PIIKILLE!!!!%%%%%%%%%%%%%%
padding = MinWidth*2;
Ic = I(padding:end-padding,:);
% se = strel('sphere',locTH);
% q = quantile(I(:),5);
% mask = imbinarize(I,q(1));
% mask = imopen(mask,se);
% mask = imclose(mask,se);
% mask = bwareafilt(mask,2);
% mask = imfill(mask,'holes');
% Ic = I.*mask;

% figure(1234)
% imshowpair(I,Ic,'montage')

Ilav = mean(Ic(:,round(0.25*size(Ic,2)):round(0.75*size(Ic,2))),2);


TFl = islocalmin(Ilav,'MinProminence',20,'ProminenceWindow',100,'MaxNumExtrema',1);
Xl = 1:length(Ilav);
lJSl = round(Ilav(TFl));

JS_loc = Xl(TFl)+padding;

% figure
% plot(Xl,Ilav,'b-')
% hold on
% plot(Xl(TFl),lJSl,'ro')
% hold off
% 
% figure
% imagesc(Ic)
% axis image
% hold on
% plot(1:size(I,2),ones(size(I,2),1).*(JS_loc-padding),'r-','LineWidth',3)
% hold off
% colormap(gray)