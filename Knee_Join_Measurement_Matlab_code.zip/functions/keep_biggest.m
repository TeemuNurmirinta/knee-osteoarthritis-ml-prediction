function biggest = keep_biggest(bwstack,N)

cc = bwconncomp(bwstack);
numPixels = cellfun(@numel,cc.PixelIdxList);
[~,idx] = maxk(numPixels,N);
biggest = zeros(size(bwstack));
for ii = 1:N
    idxn = idx(ii);
    biggest(cc.PixelIdxList{idxn}) = 1;
end

